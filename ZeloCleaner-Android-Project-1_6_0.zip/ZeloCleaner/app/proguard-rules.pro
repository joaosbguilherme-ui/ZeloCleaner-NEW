# O Shizuku instancia o serviço pelo nome da classe, e o AIDL usa reflexão em Binder.
-keep class app.zelo.limpeza.shizuku.FileService { *; }
-keep class app.zelo.limpeza.shizuku.IFileService { *; }
-keep class app.zelo.limpeza.shizuku.IFileService$Stub { *; }
-keep class app.zelo.limpeza.shizuku.IFileService$Stub$Proxy { *; }
