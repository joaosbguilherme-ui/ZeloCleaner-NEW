package app.zelo.limpeza.util;

import static org.junit.Assert.assertEquals;

import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.model.ScanMode;
import app.zelo.limpeza.scan.ReportBuilder;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class FormattersTest {
    @Test
    public void formatsBytes() {
        assertEquals("0 B", Formatters.formatBytes(0, Locale.US));
        assertEquals("1023 B", Formatters.formatBytes(1023, Locale.US));
        assertEquals("1.0 KB", Formatters.formatBytes(1024, Locale.US));
        assertEquals("1.5 MB", Formatters.formatBytes(1536L * 1024, Locale.US));
        assertEquals("2.0 GB", Formatters.formatBytes(2L * 1024 * 1024 * 1024, Locale.US));
        assertEquals("1,5 MB", Formatters.formatBytes(1536L * 1024, new Locale("pt", "BR")));
    }

    @Test
    public void reportLimitsItemsAndMentionsRemainder() {
        List<ScanFile> files = new ArrayList<>();
        for (int i = 0; i < ReportBuilder.MAX_ITEMS + 3; i++) {
            ScanFile f = new ScanFile("id" + i, "f" + i, "pasta/f" + i, 1024, 1, "text/plain");
            f.reason = "motivo";
            files.add(f);
        }
        String report = ReportBuilder.build(ScanMode.JUNK, "Downloads", "hoje", 1234, files, Locale.US);
        assertEquals(true, report.contains("Zelo — Possível lixo"));
        assertEquals(true, report.contains("Arquivos examinados: 1234"));
        assertEquals(true, report.contains("pasta/f" + (ReportBuilder.MAX_ITEMS - 1)));
        assertEquals(false, report.contains("pasta/f" + ReportBuilder.MAX_ITEMS + "  "));
        assertEquals(true, report.contains("e mais 3 item(ns)"));
    }
}
