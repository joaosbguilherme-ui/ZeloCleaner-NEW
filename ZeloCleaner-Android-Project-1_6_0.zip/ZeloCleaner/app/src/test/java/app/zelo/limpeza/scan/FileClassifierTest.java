package app.zelo.limpeza.scan;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.model.ScanMode;

import org.junit.Test;

public class FileClassifierTest {
    private static final long DAY = 24L * 60 * 60 * 1000;
    private static final long NOW = 1_800_000_000_000L;

    private static ScanFile file(String path, long size, long modified) {
        String name = path.substring(path.lastIndexOf('/') + 1);
        return new ScanFile("id:" + path, name, path, size, modified, "application/octet-stream");
    }

    @Test
    public void junkByExtension() {
        assertTrue(FileClassifier.looksLikeJunk("a.tmp", "docs/a.tmp"));
        assertTrue(FileClassifier.looksLikeJunk("A.LOG", "docs/A.LOG"));
        assertTrue(FileClassifier.looksLikeJunk("x.bak", "x.bak"));
        assertTrue(FileClassifier.looksLikeJunk("Thumbs.db", "pics/Thumbs.db"));
        assertTrue(FileClassifier.looksLikeJunk(".trashed-123-foto.jpg", "DCIM/.trashed-123-foto.jpg"));
    }

    @Test
    public void junkByFolder() {
        assertTrue(FileClassifier.looksLikeJunk("a.dat", "cache/a.dat"));
        assertTrue(FileClassifier.looksLikeJunk("a.dat", "app/Tmp/a.dat"));
        assertTrue(FileClassifier.looksLikeJunk("a.dat", "app\\cache\\a.dat"));
    }

    @Test
    public void normalFilesAreNotJunk() {
        assertFalse(FileClassifier.looksLikeJunk("foto.jpg", "DCIM/foto.jpg"));
        assertFalse(FileClassifier.looksLikeJunk("catalog.txt", "docs/catalog.txt"));
        assertFalse(FileClassifier.looksLikeJunk("template.doc", "template/template.doc"));
    }

    @Test
    public void largeThreshold() {
        assertNull(FileClassifier.reasonFor(ScanMode.LARGE, file("a", FileClassifier.LARGE_FILE_BYTES - 1, NOW), NOW));
        assertNotNull(FileClassifier.reasonFor(ScanMode.LARGE, file("a", FileClassifier.LARGE_FILE_BYTES, NOW), NOW));
    }

    @Test
    public void oldIgnoresUnknownDates() {
        assertNull(FileClassifier.reasonFor(ScanMode.OLD, file("a", 1, 0), NOW));
        assertNull(FileClassifier.reasonFor(ScanMode.OLD, file("a", 1, NOW - 179 * DAY), NOW));
        assertNotNull(FileClassifier.reasonFor(ScanMode.OLD, file("a", 1, NOW - 181 * DAY), NOW));
    }

    @Test
    public void duplicatesModeNeverMatchesByRule() {
        assertNull(FileClassifier.reasonFor(ScanMode.DUPLICATES, file("a.tmp", 999999999L, 1), NOW));
        assertEquals("Nome ou pasta sugere arquivo temporário",
                FileClassifier.reasonFor(ScanMode.JUNK, file("a.tmp", 1, NOW), NOW));
    }
}
