package app.zelo.limpeza.scan;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import app.zelo.limpeza.model.ScanFile;

import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TreeWalkerTest {
    private static File tempTree() throws IOException {
        File root = Files.createTempDirectory("zelo-walk").toFile();
        new File(root, "a/b").mkdirs();
        new File(root, "vazia").mkdirs();
        Files.write(new File(root, "raiz.txt").toPath(), new byte[10]);
        Files.write(new File(root, "a/um.jpg").toPath(), new byte[20]);
        Files.write(new File(root, "a/b/dois.mp4").toPath(), new byte[30]);
        return root;
    }

    private static List<String> paths(List<ScanFile> files) {
        List<String> p = new ArrayList<>();
        for (ScanFile f : files) p.add(f.relativePath);
        Collections.sort(p);
        return p;
    }

    @Test
    public void walksLocalTreeWithRelativePathsAndMime() throws IOException {
        File root = tempTree();
        List<ScanFile> found = new ArrayList<>();
        TreeWalker.Summary s = TreeWalker.walk(new LocalLister(), root.getAbsolutePath(), () -> false, found::add);
        assertEquals(3, s.scanned);
        assertFalse(s.truncated);
        assertEquals(java.util.Arrays.asList("a/b/dois.mp4", "a/um.jpg", "raiz.txt"), paths(found));
        for (ScanFile f : found) {
            if (f.name.equals("um.jpg")) { assertEquals("image/jpeg", f.mimeType); assertEquals(20, f.size); }
            if (f.name.equals("dois.mp4")) assertEquals("video/mp4", f.mimeType);
            assertTrue(new File(f.documentId).isFile());
        }
    }

    @Test
    public void respectsMaxFilesAndMarksTruncated() throws IOException {
        File root = tempTree();
        List<ScanFile> found = new ArrayList<>();
        TreeWalker.Summary s = TreeWalker.walk(new LocalLister(), root.getAbsolutePath(), () -> false,
                MimeTypes::guess, 2, found::add);
        assertEquals(2, s.scanned);
        assertTrue(s.truncated);
        assertEquals(2, found.size());
    }

    @Test
    public void cancellationStopsWalking() throws IOException {
        File root = tempTree();
        List<ScanFile> found = new ArrayList<>();
        TreeWalker.walk(new LocalLister(), root.getAbsolutePath(), () -> true, found::add);
        assertTrue(found.isEmpty());
    }

    @Test
    public void unreadableDirectoryIsSkipped() {
        TreeWalker.Lister broken = id -> { throw new IOException("negado"); };
        TreeWalker.Summary s = TreeWalker.walk(broken, "/x", () -> false, f -> { });
        assertEquals(0, s.scanned);
    }

    @Test
    public void doesNotFollowSymlinks() throws IOException {
        File root = tempTree();
        File outside = Files.createTempDirectory("zelo-outside").toFile();
        Files.write(new File(outside, "segredo.txt").toPath(), new byte[5]);
        try {
            Files.createSymbolicLink(new File(root, "atalho").toPath(), outside.toPath());
        } catch (UnsupportedOperationException | IOException e) {
            return; // sistema sem links simbólicos
        }
        List<ScanFile> found = new ArrayList<>();
        TreeWalker.walk(new LocalLister(), root.getAbsolutePath(), () -> false, found::add);
        for (ScanFile f : found) assertFalse(f.relativePath.contains("segredo"));
        assertEquals(3, found.size());
    }

    @Test
    public void usesEntryMimeWhenProvided() {
        TreeWalker.Lister l = id -> java.util.Collections.singletonList(
                new TreeWalker.Entry("id1", "sem-extensao", false, 5, 1, "image/png"));
        List<ScanFile> found = new ArrayList<>();
        TreeWalker.walk(l, "root", () -> false, found::add);
        assertEquals("image/png", found.get(0).mimeType);
    }
}
