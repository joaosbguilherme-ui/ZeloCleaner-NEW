package app.zelo.limpeza.scan;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import app.zelo.limpeza.model.DuplicateGroup;
import app.zelo.limpeza.model.ScanFile;

import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DuplicateFinderTest {
    private final Map<String, byte[]> contents = new HashMap<>();
    private int opens;

    private final DuplicateFinder.ContentSource source = f -> {
        opens++;
        byte[] data = contents.get(f.documentId);
        if (data == null) throw new IOException("sem conteúdo");
        return new ByteArrayInputStream(data);
    };

    private ScanFile add(String path, byte[] data, long modified) {
        contents.put(path, data);
        return new ScanFile(path, path.substring(path.lastIndexOf('/') + 1), path, data.length, modified, "text/plain");
    }

    private static byte[] bytes(int length, int seed) {
        byte[] b = new byte[length];
        for (int i = 0; i < length; i++) b[i] = (byte) (i * 31 + seed);
        return b;
    }

    private List<DuplicateGroup> find(List<ScanFile> files) {
        return DuplicateFinder.find(files, source, () -> false, null);
    }

    @Test
    public void findsIdenticalSmallFilesAndKeepsOldestAsOriginal() {
        List<ScanFile> files = new ArrayList<>();
        files.add(add("b/copia.txt", bytes(100, 1), 2000));
        files.add(add("a/original.txt", bytes(100, 1), 1000));
        files.add(add("c/outro.txt", bytes(100, 2), 500));
        List<DuplicateGroup> groups = find(files);
        assertEquals(1, groups.size());
        assertEquals("a/original.txt", groups.get(0).original.relativePath);
        assertEquals(1, groups.get(0).copies.size());
        assertEquals("b/copia.txt", groups.get(0).copies.get(0).relativePath);
        assertTrue(groups.get(0).copies.get(0).reason.contains("a/original.txt"));
        assertEquals(100, groups.get(0).wastedBytes());
    }

    @Test
    public void sameSizeDifferentContentIsNotDuplicate() {
        List<ScanFile> files = Arrays.asList(add("x", bytes(50, 1), 1), add("y", bytes(50, 2), 2));
        assertTrue(find(files).isEmpty());
    }

    @Test
    public void largeFilesDifferingAfterQuickHashAreSeparated() {
        int size = DuplicateFinder.QUICK_HASH_BYTES * 3;
        byte[] a = bytes(size, 7);
        byte[] b = a.clone();
        b[size - 1] ^= 0x55; // igual nos primeiros 64 KB, diferente no final
        byte[] c = a.clone();
        List<ScanFile> files = Arrays.asList(add("a", a, 1), add("b", b, 2), add("c", c, 3));
        List<DuplicateGroup> groups = find(files);
        assertEquals(1, groups.size());
        assertEquals("a", groups.get(0).original.relativePath);
        assertEquals("c", groups.get(0).copies.get(0).relativePath);
    }

    @Test
    public void emptyFilesAndSingletonsAreIgnoredWithoutReading() {
        List<ScanFile> files = Arrays.asList(add("e1", new byte[0], 1), add("e2", new byte[0], 2), add("solo", bytes(10, 3), 3));
        assertTrue(find(files).isEmpty());
        assertEquals(0, opens);
    }

    @Test
    public void unreadableFilesAreSkipped() {
        ScanFile a = add("a", bytes(20, 1), 1);
        ScanFile b = add("b", bytes(20, 1), 2);
        contents.remove("b");
        assertTrue(find(Arrays.asList(a, b)).isEmpty());
    }

    @Test
    public void unknownDateIsNeverTheOriginalWhenOthersHaveDates() {
        List<ScanFile> files = Arrays.asList(add("sem-data", bytes(30, 9), 0), add("com-data", bytes(30, 9), 5000));
        assertEquals("com-data", find(files).get(0).original.relativePath);
    }

    @Test
    public void cancellationStopsEarly() {
        List<ScanFile> files = Arrays.asList(add("a", bytes(30, 9), 1), add("b", bytes(30, 9), 2));
        List<DuplicateGroup> groups = DuplicateFinder.find(files, source, () -> true, null);
        assertTrue(groups.isEmpty());
    }

    @Test
    public void reportsProgress() {
        List<ScanFile> files = Arrays.asList(add("a", bytes(30, 9), 1), add("b", bytes(30, 9), 2), add("c", bytes(31, 9), 3));
        int[] last = {0, 0};
        DuplicateFinder.find(files, source, () -> false, (done, total) -> { last[0] = done; last[1] = total; });
        assertEquals(2, last[0]);
        assertEquals(2, last[1]);
    }
}
