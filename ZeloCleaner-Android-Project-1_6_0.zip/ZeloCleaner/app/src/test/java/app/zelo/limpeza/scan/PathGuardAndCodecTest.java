package app.zelo.limpeza.scan;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public class PathGuardAndCodecTest {
    @Test
    public void guardAcceptsOnlyStrictlyInsidePaths() throws IOException {
        File root = Files.createTempDirectory("zelo-guard").toFile();
        File inside = new File(root, "data/app/x.bin");
        inside.getParentFile().mkdirs();
        assertTrue(PathGuard.isStrictlyInside(root.getPath(), inside.getPath()));
        assertFalse(PathGuard.isStrictlyInside(root.getPath(), root.getPath()));            // a própria raiz
        assertFalse(PathGuard.isStrictlyInside(root.getPath(), root.getPath() + "/../outro")); // escapa com ..
        assertFalse(PathGuard.isStrictlyInside(root.getPath(), root.getPath() + "-irmao/x")); // prefixo parecido
        assertFalse(PathGuard.isStrictlyInside(root.getPath() + "/data", root.getPath() + "/dataX/y"));
    }

    @Test
    public void guardResolvesSymlinksPointingOutside() throws IOException {
        File root = Files.createTempDirectory("zelo-guard2").toFile();
        File outside = Files.createTempDirectory("zelo-out2").toFile();
        File target = new File(outside, "alvo.txt");
        Files.write(target.toPath(), new byte[1]);
        try {
            Files.createSymbolicLink(new File(root, "link").toPath(), target.toPath());
        } catch (UnsupportedOperationException | IOException e) {
            return;
        }
        assertFalse(PathGuard.isStrictlyInside(root.getPath(), root.getPath() + "/link"));
    }

    @Test
    public void guardAny() throws IOException {
        File root = Files.createTempDirectory("zelo-guard3").toFile();
        new File(root, "obb").mkdirs();
        assertTrue(PathGuard.isStrictlyInsideAny(root.getPath() + "/obb/p/f", root.getPath() + "/data", root.getPath() + "/obb"));
        assertFalse(PathGuard.isStrictlyInsideAny(root.getPath() + "/outra/f", root.getPath() + "/data", root.getPath() + "/obb"));
    }

    @Test
    public void codecRoundTrip() {
        String line = EntryCodec.encode("com.app", true, 0, 123);
        TreeWalker.Entry e = EntryCodec.decode("/storage/emulated/0/Android/data/", line);
        assertEquals("/storage/emulated/0/Android/data/com.app", e.id);
        assertTrue(e.directory);
        assertEquals(123, e.modified);
    }

    @Test
    public void codecKeepsTabsInNamesAndRejectsGarbage() {
        TreeWalker.Entry e = EntryCodec.decode("/p", EntryCodec.encode("a\tb.txt", false, 77, 5));
        assertEquals("a\tb.txt", e.name);
        assertEquals(77, e.size);
        assertNull(EntryCodec.decode("/p", "lixo"));
        assertNull(EntryCodec.decode("/p", "x\t1\t2\tnome"));
        assertNull(EntryCodec.decode("/p", "f\tabc\t2\tnome"));
        assertNull(EntryCodec.decode("/p", null));
    }
}
