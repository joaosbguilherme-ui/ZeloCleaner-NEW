package app.zelo.limpeza.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SortAndRowsTest {
    private static ScanFile f(String name, long size, long modified) {
        return new ScanFile("id/" + name, name, "dir/" + name, size, modified, "text/plain");
    }

    private static List<String> names(List<ScanFile> files, SortOrder order) {
        List<ScanFile> copy = new ArrayList<>(files);
        Collections.sort(copy, order.fileComparator());
        List<String> out = new ArrayList<>();
        for (ScanFile x : copy) out.add(x.name);
        return out;
    }

    private final List<ScanFile> sample = Arrays.asList(
            f("banana", 10, 300), f("Abacate", 30, 100), f("cereja", 20, 0), f("damasco", 20, 200));

    @Test
    public void sortBySizeDescending() {
        assertEquals(Arrays.asList("Abacate", "cereja", "damasco", "banana"), names(sample, SortOrder.SIZE));
    }

    @Test
    public void sortByNameIgnoresCase() {
        assertEquals(Arrays.asList("Abacate", "banana", "cereja", "damasco"), names(sample, SortOrder.NAME));
    }

    @Test
    public void sortByDateKeepsUnknownDatesLast() {
        assertEquals(Arrays.asList("Abacate", "damasco", "banana", "cereja"), names(sample, SortOrder.OLDEST));
        assertEquals(Arrays.asList("banana", "damasco", "Abacate", "cereja"), names(sample, SortOrder.NEWEST));
    }

    @Test
    public void flatModeBuildsOnlyFileRows() {
        List<ResultRow> rows = RowBuilder.build(ScanMode.LARGE, sample, new ArrayList<>(), SortOrder.NAME);
        assertEquals(4, rows.size());
        for (ResultRow r : rows) assertFalse(r.isHeader());
    }

    @Test
    public void duplicateModeGroupsWithHeadersAndSortsGroupsBySavedSpace() {
        DuplicateGroup small = new DuplicateGroup(f("o1", 10, 1), Arrays.asList(f("c1", 10, 2)));
        DuplicateGroup big = new DuplicateGroup(f("o2", 500, 1), Arrays.asList(f("c2", 500, 2), f("c3", 500, 3)));
        DuplicateGroup empty = new DuplicateGroup(f("o3", 5, 1), new ArrayList<>());
        List<ResultRow> rows = RowBuilder.build(ScanMode.DUPLICATES, new ArrayList<>(),
                Arrays.asList(small, big, empty), SortOrder.SIZE);
        assertEquals(5, rows.size()); // 2 cabeçalhos + 3 cópias; grupo vazio omitido
        assertTrue(rows.get(0).isHeader());
        assertEquals(big, rows.get(0).group);
        assertTrue(rows.get(3).isHeader());
        assertEquals(small, rows.get(3).group);
    }
}
