package app.zelo.limpeza.scan;

import static org.junit.Assert.assertEquals;

import app.zelo.limpeza.model.FileCategory;
import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.model.SpaceSummary;

import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class SpaceAnalyzerTest {
    private static ScanFile f(String path, long size) {
        String name = path.substring(path.lastIndexOf('/') + 1);
        return new ScanFile("id:" + path, name, path, size, 1, MimeTypes.guess(name));
    }

    @Test
    public void categorizes() {
        assertEquals(FileCategory.IMAGES, FileCategory.of("image/png", "a.png"));
        assertEquals(FileCategory.VIDEOS, FileCategory.of("video/mp4", "a.mp4"));
        assertEquals(FileCategory.AUDIO, FileCategory.of("audio/mpeg", "a.mp3"));
        assertEquals(FileCategory.APPS, FileCategory.of("application/octet-stream", "base.apk"));
        assertEquals(FileCategory.ARCHIVES, FileCategory.of("application/octet-stream", "x.7z"));
        assertEquals(FileCategory.DOCUMENTS, FileCategory.of("application/pdf", "a.pdf"));
        assertEquals(FileCategory.DOCUMENTS, FileCategory.of("text/plain", "a"));
        assertEquals(FileCategory.OTHER, FileCategory.of("application/octet-stream", "dados.bin"));
    }

    @Test
    public void sumsByCategoryAndFolderDepth() {
        SpaceAnalyzer a = new SpaceAnalyzer(2);
        a.add(f("DCIM/Camera/1.jpg", 100));
        a.add(f("DCIM/Camera/2.mp4", 400));
        a.add(f("DCIM/outras/3.jpg", 50));
        a.add(f("Download/x.pdf", 30));
        a.add(f("raiz.bin", 7));
        SpaceSummary s = a.result(10);
        assertEquals(587, s.totalBytes);
        assertEquals(5, s.totalFiles);
        assertEquals(150, s.categories.get(FileCategory.IMAGES).bytes);
        assertEquals(2, s.categories.get(FileCategory.IMAGES).count);
        assertEquals(400, s.categories.get(FileCategory.VIDEOS).bytes);
        assertEquals("DCIM", s.folders.get(0).path);
        assertEquals(550, s.folders.get(0).bytes);
        assertEquals("DCIM/Camera", s.folders.get(1).path);
        assertEquals(500, s.folders.get(1).bytes);
        assertEquals(4, s.folders.size()); // DCIM, DCIM/Camera, DCIM/outras, Download (sem a raiz)
    }

    @Test
    public void limitsFolderList() {
        SpaceAnalyzer a = new SpaceAnalyzer(1);
        for (int i = 0; i < 5; i++) a.add(f("p" + i + "/x.bin", 10 + i));
        assertEquals(3, a.result(3).folders.size());
        assertEquals("p4", a.result(3).folders.get(0).path);
    }

    @Test
    public void ranksAppsAcrossDataAndObb() {
        SpaceAnalyzer a = new SpaceAnalyzer(2);
        a.add(f("data/com.jogo/files/a.bin", 300));
        a.add(f("obb/com.jogo/main.obb", 900));
        a.add(f("data/com.chat/cache/b.bin", 500));
        a.add(f("data/com.pequeno/x.bin", 1));
        List<AppSpaceRanker.AppSpace> ranking = AppSpaceRanker.rank(a.result(Integer.MAX_VALUE).folders);
        assertEquals(3, ranking.size());
        assertEquals("com.jogo", ranking.get(0).packageName);
        assertEquals(1200, ranking.get(0).total());
        assertEquals(300, ranking.get(0).dataBytes);
        assertEquals(900, ranking.get(0).obbBytes);
        assertEquals("com.chat", ranking.get(1).packageName);
    }

    @Test
    public void rankerIgnoresUnrelatedFolders() {
        List<SpaceSummary.FolderTotal> in = new ArrayList<>();
        in.add(new SpaceSummary.FolderTotal("data", 10, 1));
        in.add(new SpaceSummary.FolderTotal("media/com.x", 10, 1));
        in.add(new SpaceSummary.FolderTotal("data/com.x/files", 10, 1));
        assertEquals(0, AppSpaceRanker.rank(in).size());
    }
}
