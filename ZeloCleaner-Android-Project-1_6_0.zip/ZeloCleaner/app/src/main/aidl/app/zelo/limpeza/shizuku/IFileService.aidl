package app.zelo.limpeza.shizuku;

import android.os.ParcelFileDescriptor;

// Serviço que roda no processo de shell iniciado pelo Shizuku (UID 2000).
interface IFileService {
    // Método reservado pelo Shizuku para encerrar o serviço.
    void destroy() = 16777114;

    // Lista uma pasta em Android/, Android/data ou Android/obb (linhas no formato EntryCodec).
    // Retorna null se o caminho não for permitido.
    String[] listDir(String path, int offset, int max) = 1;

    ParcelFileDescriptor openRead(String path) = 2;

    // Exclui um arquivo comum dentro de Android/data ou Android/obb.
    boolean deleteFile(String path) = 3;

    // Executa "pm trim-caches <bytes>" e devolve a saída.
    String trimCaches(long bytes) = 4;
}
