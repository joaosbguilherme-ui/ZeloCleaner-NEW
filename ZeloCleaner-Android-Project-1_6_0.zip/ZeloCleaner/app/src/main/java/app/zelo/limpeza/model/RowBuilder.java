package app.zelo.limpeza.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Monta a lista exibida (com agrupamento de duplicados) a partir dos resultados e da ordenação escolhida. */
public final class RowBuilder {
    private RowBuilder() { }

    public static List<ResultRow> build(ScanMode mode, List<ScanFile> files, List<DuplicateGroup> groups, SortOrder order) {
        List<ResultRow> rows = new ArrayList<>();
        if (mode == ScanMode.DUPLICATES) {
            List<DuplicateGroup> sortedGroups = new ArrayList<>(groups);
            Collections.sort(sortedGroups, order.groupComparator());
            for (DuplicateGroup g : sortedGroups) {
                if (g.copies.isEmpty()) continue;
                rows.add(ResultRow.header(g));
                List<ScanFile> copies = new ArrayList<>(g.copies);
                Collections.sort(copies, order.fileComparator());
                for (ScanFile f : copies) rows.add(ResultRow.file(f));
            }
        } else {
            List<ScanFile> sorted = new ArrayList<>(files);
            Collections.sort(sorted, order.fileComparator());
            for (ScanFile f : sorted) rows.add(ResultRow.file(f));
        }
        return rows;
    }
}
