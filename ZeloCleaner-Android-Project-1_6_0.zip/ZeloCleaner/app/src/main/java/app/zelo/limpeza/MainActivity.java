package app.zelo.limpeza;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import androidx.documentfile.provider.DocumentFile;

import app.zelo.limpeza.model.DuplicateGroup;
import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.model.ScanMode;
import app.zelo.limpeza.model.SpaceSummary;
import app.zelo.limpeza.scan.AppSpaceRanker;
import app.zelo.limpeza.scan.ScanController;
import app.zelo.limpeza.shizuku.ShizukuHelper;
import app.zelo.limpeza.source.DirectSource;
import app.zelo.limpeza.source.FileSource;
import app.zelo.limpeza.source.SafSource;
import app.zelo.limpeza.source.ShizukuSource;
import app.zelo.limpeza.source.SourceType;
import app.zelo.limpeza.ui.FileActions;
import app.zelo.limpeza.ui.ResultsScreen;
import app.zelo.limpeza.ui.SummaryViews;
import app.zelo.limpeza.ui.UiKit;
import app.zelo.limpeza.util.StorageInfo;

import androidx.appcompat.app.AlertDialog;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.radiobutton.MaterialRadioButton;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.color.DynamicColors;

import java.util.List;
import java.util.function.Consumer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static app.zelo.limpeza.ui.UiKit.*;

/**
 * Zelo: utilitário de organização do armazenamento.
 * Esta classe cuida só da navegação e do estado; varredura, regras e listas ficam em pacotes próprios.
 * A análise percorre apenas a pasta que a pessoa escolhe pelo seletor oficial do Android.
 */
public class MainActivity extends Activity implements ResultsScreen.Host {
    private static final int REQUEST_FOLDER = 7041;
    private static final String PREFS = "zelo_preferences";
    private static final String PREF_TREE_URI = "selected_tree_uri";
    private static final String PREF_SOURCE = "source_type";
    private static final String PREF_THEME_MODE = "theme_mode";
    private static final String PREF_DYNAMIC_COLORS = "dynamic_colors";
    private static final String STATE_APPEARANCE = "showing_appearance";
    private static final int MAX_FAILURES_SHOWN = 10;

    private final ScanController scanner = new ScanController();
    private final ExecutorService ioWorker = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private UiKit ui;
    private ScrollView shell;
    private LinearLayout content;
    private ResultsScreen results;
    private TextView liveProgress;
    private Uri folderUri;
    private String folderName = "Nenhuma pasta escolhida";
    private boolean scanning = false;
    private boolean deleting = false;
    private boolean onHome = true;
    private boolean showingAppearance = false;
    private AlertDialog deleteDialog;
    private final ShizukuHelper shizuku = new ShizukuHelper();
    private SourceType sourceType = SourceType.SAF;
    private FileSource activeSource;
    private OnBackInvokedCallback backCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String themeMode = prefs.getString(PREF_THEME_MODE, "system");
        if ("light".equals(themeMode)) setTheme(R.style.AppTheme_Light);
        else if ("dark".equals(themeMode)) setTheme(R.style.AppTheme_Dark);
        else setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        if (prefs.getBoolean(PREF_DYNAMIC_COLORS, true)) {
            // Aplica a paleta do sistema antes de criar qualquer componente da interface.
            DynamicColors.applyToActivityIfAvailable(this);
        }
        UiKit.applyTheme(this);
        ui = new UiKit(this);
        setupSystemBars();
        sourceType = SourceType.fromName(prefs.getString(PREF_SOURCE, SourceType.SAF.name()));
        shizuku.attach(this);
        String savedUri = prefs.getString(PREF_TREE_URI, null);
        if (savedUri != null) {
            try {
                folderUri = Uri.parse(savedUri);
                DocumentFile root = DocumentFile.fromTreeUri(this, folderUri);
                if (root != null && root.getName() != null) folderName = root.getName();
            } catch (Exception ignored) {
                folderUri = null;
            }
        }
        buildShell();
        if (Build.VERSION.SDK_INT >= 33) backCallback = this::handleBack;
        if (savedInstanceState != null && savedInstanceState.getBoolean(STATE_APPEARANCE, false)) renderAppearance();
        else renderHome();
    }

    // ---------- janela e navegação ----------

    private void setupSystemBars() {
        Window window = getWindow();
        window.setStatusBarColor(BG);
        window.setNavigationBarColor(BG);
        boolean light = isLightTheme();
        if (Build.VERSION.SDK_INT >= 23) {
            int flags = window.getDecorView().getSystemUiVisibility();
            if (light) flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= 26) {
                if (light) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                else flags &= ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            window.getDecorView().setSystemUiVisibility(flags);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false);
            window.setStatusBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= 30) window.setDecorFitsSystemWindows(false);
    }

    private void applyInsets(View root) {
        if (Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                view.setPadding(0, bars.top, 0, bars.bottom);
                return insets;
            });
            root.requestApplyInsets();
        } else {
            root.setPadding(0, ui.dp(8), 0, ui.dp(8));
        }
    }

    private void buildShell() {
        shell = new ScrollView(this);
        shell.setFillViewport(true);
        shell.setClipToPadding(false);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(ui.dp(20), ui.dp(20), ui.dp(20), ui.dp(32));
        content.setBackgroundColor(BG);
        shell.addView(content, new ScrollView.LayoutParams(-1, -2));
        applyInsets(shell);
    }

    /** Mostra a tela simples (início, carregando, mensagem). */
    private void showShell() {
        showingAppearance = false;
        disposeResults();
        setContentView(shell);
        setOnHome(false);
        content.removeAllViews();
    }

    private void disposeResults() {
        if (results != null) {
            results.shutdown();
            results = null;
        }
        liveProgress = null;
    }

    private void setOnHome(boolean home) {
        if (onHome == home) return;
        onHome = home;
        if (Build.VERSION.SDK_INT >= 33 && backCallback != null) {
            if (home) getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
            else getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback);
        }
    }

    private void handleBack() {
        if (deleting) {
            Toast.makeText(this, "Aguarde a exclusão terminar.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (scanning) {
            scanner.cancel();
            scanning = false;
        }
        renderHome();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (onHome) super.onBackPressed();
        else handleBack();
    }

    // ---------- início ----------

    private void renderHome() {
        showShell();
        setOnHome(true);
        addHomeHeader();

        // Cartão de armazenamento (hero).
        StorageInfo storage = StorageInfo.read();
        int ringColor;
        int chipBg;
        int chipFg;
        String status;
        if (storage.totalBytes <= 0) {
            ringColor = ACCENT; chipBg = CARD_ALT; chipFg = MUTED; status = "Indisponível";
        } else if (storage.percent >= 90) {
            ringColor = DANGER; chipBg = DANGER_CONTAINER; chipFg = ON_DANGER_CONTAINER; status = "Armazenamento quase cheio";
        } else if (storage.percent >= 75) {
            ringColor = WARNING; chipBg = WARNING_CONTAINER; chipFg = ON_WARNING_CONTAINER; status = "Pouco espaço livre";
        } else {
            ringColor = ACCENT; chipBg = ACCENT_CONTAINER; chipFg = ON_ACCENT_CONTAINER; status = "Espaço confortável";
        }

        LinearLayout storageCard = ui.card();
        storageCard.setPadding(ui.dp(20), ui.dp(20), ui.dp(20), ui.dp(18));
        LinearLayout storageHeading = new LinearLayout(this);
        storageHeading.setOrientation(LinearLayout.HORIZONTAL);
        storageHeading.setGravity(Gravity.CENTER_VERTICAL);
        storageHeading.addView(ui.badge(R.drawable.ic_phone, ACCENT, ACCENT_CONTAINER, 24, 16),
                new LinearLayout.LayoutParams(ui.dp(46), ui.dp(46)));
        LinearLayout storageTitle = new LinearLayout(this);
        storageTitle.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(0, -2, 1f);
        titleLp.leftMargin = ui.dp(13);
        storageHeading.addView(storageTitle, titleLp);
        storageTitle.addView(ui.text("Armazenamento interno", 16, TEXT, true));
        storageTitle.addView(ui.text("Visão geral do dispositivo", 12, MUTED, false), margin(3));
        storageCard.addView(storageHeading);

        LinearLayout storageMain = new LinearLayout(this);
        storageMain.setOrientation(LinearLayout.HORIZONTAL);
        storageMain.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout storageNumbers = new LinearLayout(this);
        storageNumbers.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams numbersLp = new LinearLayout.LayoutParams(0, -2, 1f);
        numbersLp.rightMargin = ui.dp(12);
        storageMain.addView(storageNumbers, numbersLp);
        TextView usedLabel = ui.text("ESPAÇO EM USO", 10, MUTED, true);
        usedLabel.setLetterSpacing(0.10f);
        storageNumbers.addView(usedLabel);
        TextView usedValue = ui.text(storage.usedValueText, 29, TEXT, true);
        usedValue.setLetterSpacing(-0.03f);
        storageNumbers.addView(usedValue, margin(5));
        storageNumbers.addView(ui.text(storage.subText, 12, MUTED, false), margin(4));
        TextView statusChip = ui.chip(status, chipBg, chipFg);
        LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(-2, -2);
        chipLp.topMargin = ui.dp(10);
        storageNumbers.addView(statusChip, chipLp);

        FrameLayout ringFrame = new FrameLayout(this);
        int ringSize = ui.dp(104);
        CircularProgressIndicator storageRing = new CircularProgressIndicator(this);
        storageRing.setIndicatorSize(ringSize);
        storageRing.setTrackThickness(ui.dp(10));
        storageRing.setTrackCornerRadius(ui.dp(8));
        storageRing.setIndeterminate(false);
        storageRing.setMax(100);
        storageRing.setIndicatorColor(ringColor);
        storageRing.setTrackColor(CARD_ALT);
        ringFrame.addView(storageRing, new FrameLayout.LayoutParams(ringSize, ringSize, Gravity.CENTER));
        TextView percentText = ui.text(storage.totalBytes > 0 ? storage.percent + "%" : "—", 20, TEXT, true);
        percentText.setGravity(Gravity.CENTER);
        ringFrame.addView(percentText, new FrameLayout.LayoutParams(ringSize, ringSize, Gravity.CENTER));
        storageMain.addView(ringFrame, new LinearLayout.LayoutParams(ringSize, ringSize));
        storageCard.addView(storageMain, margin(22));
        // Anima o anel do zero até o valor real.
        storageRing.setProgressCompat(storage.percent, true);

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(LinearLayout.HORIZONTAL);
        metrics.addView(storageMetric("LIVRE", storage.freeValueText), new LinearLayout.LayoutParams(0, -2, 1f));
        metrics.addView(new View(this), new LinearLayout.LayoutParams(ui.dp(10), 1));
        metrics.addView(storageMetric("CAPACIDADE", storage.totalValueText), new LinearLayout.LayoutParams(0, -2, 1f));
        storageCard.addView(metrics, margin(18));

        MaterialButton detailButton = ui.button("Ver análise detalhada", ACCENT, BG, R.drawable.ic_arrow_forward, true);
        LinearLayout.LayoutParams detailLp = new LinearLayout.LayoutParams(-1, ui.dp(50));
        detailLp.topMargin = ui.dp(16);
        storageCard.addView(detailButton, detailLp);
        detailButton.setOnClickListener(v -> startSpaceSummary());
        addCard(storageCard);

        // Ferramentas principais em grade 2×2.
        addSectionLabel("Ferramentas");
        addToolRow(
                toolTile(R.drawable.ic_file, "Arquivos grandes", "100 MB ou mais", WARNING_CONTAINER, ON_WARNING_CONTAINER, () -> startScan(ScanMode.LARGE)),
                toolTile(R.drawable.ic_copy, "Duplicados", "Cópias idênticas pelo conteúdo", ACCENT_CONTAINER, ON_ACCENT_CONTAINER, () -> startScan(ScanMode.DUPLICATES)));
        addToolRow(
                toolTile(R.drawable.ic_sweep, "Possíveis resíduos", "Temporários, logs e backups", SECONDARY_CONTAINER, ON_SECONDARY_CONTAINER, () -> startScan(ScanMode.JUNK)),
                toolTile(R.drawable.ic_schedule, "Arquivos antigos", "Sem alteração há 180 dias", CARD_ALT, TEXT, () -> startScan(ScanMode.OLD)));

        // Fonte de análise.
        LinearLayout sourceCard = ui.card();
        LinearLayout sourceHead = new LinearLayout(this);
        sourceHead.setOrientation(LinearLayout.HORIZONTAL);
        sourceHead.setGravity(Gravity.CENTER_VERTICAL);
        sourceHead.addView(ui.badge(R.drawable.ic_folder, ACCENT, ACCENT_CONTAINER, 22, 14),
                new LinearLayout.LayoutParams(ui.dp(42), ui.dp(42)));
        LinearLayout sourceTexts = new LinearLayout(this);
        sourceTexts.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams sourceTextsLp = new LinearLayout.LayoutParams(0, -2, 1f);
        sourceTextsLp.leftMargin = ui.dp(12);
        sourceHead.addView(sourceTexts, sourceTextsLp);
        sourceTexts.addView(ui.text("FONTE DE ANÁLISE", 10, ACCENT, true));
        sourceTexts.addView(ui.text(sourceType.label, 15, TEXT, true), margin(2));
        sourceCard.addView(sourceHead);
        String detail = sourceType == SourceType.SAF ? "Pasta: " + folderName : sourceType.description;
        sourceCard.addView(ui.text(detail, 12, MUTED, false), margin(10));
        sourceCard.addView(ui.text("Nenhum arquivo é apagado automaticamente.", 12, MUTED, false), margin(4));
        LinearLayout sourceButtons = new LinearLayout(this);
        sourceButtons.setOrientation(LinearLayout.HORIZONTAL);
        MaterialButton sourceButton = ui.button("Alterar fonte", ACCENT_CONTAINER, ON_ACCENT_CONTAINER, R.drawable.ic_swap, false);
        sourceButtons.addView(sourceButton, new LinearLayout.LayoutParams(0, ui.dp(48), 1f));
        sourceButton.setOnClickListener(v -> chooseSource());
        if (sourceType == SourceType.SAF) {
            MaterialButton chooseButton = ui.button("Escolher pasta", CARD_ALT, TEXT, R.drawable.ic_folder, false);
            LinearLayout.LayoutParams chooseLp = new LinearLayout.LayoutParams(0, ui.dp(48), 1f);
            chooseLp.leftMargin = ui.dp(8);
            sourceButtons.addView(chooseButton, chooseLp);
            chooseButton.setOnClickListener(v -> chooseFolder());
        }
        sourceCard.addView(sourceButtons, margin(14));
        content.addView(sourceCard, margin(2));

        addSectionLabel("Ferramentas avançadas · Shizuku");
        addAction(R.drawable.ic_apps, "Apps por espaço", "Quanto cada app guarda em Android/data e obb.", WARNING_CONTAINER, ON_WARNING_CONTAINER, this::startAppRanking);
        addAction(R.drawable.ic_bolt, "Limpar caches dos apps", "Pede ao sistema para liberar caches (via Shizuku).", WARNING_CONTAINER, ON_WARNING_CONTAINER, this::trimCaches);

        addSectionLabel("Sistema");
        addAction(R.drawable.ic_palette, "Aparência e cores", "Tema claro, escuro e cores dinâmicas do papel de parede.", ACCENT_CONTAINER, ON_ACCENT_CONTAINER, this::renderAppearance);
        addAction(R.drawable.ic_tune, "Configurações de aplicativos", "Abra as configurações do Android para revisar apps.", CARD_ALT, TEXT, this::openAppSettings);

        LinearLayout footer = new LinearLayout(this);
        footer.setOrientation(LinearLayout.HORIZONTAL);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(ui.dp(8), ui.dp(18), ui.dp(8), ui.dp(10));
        footer.addView(ui.icon(R.drawable.ic_shield, MUTED), new LinearLayout.LayoutParams(ui.dp(16), ui.dp(16)));
        TextView footerText = ui.text("Zelo não usa internet e não limpa dados privados de outros apps. A exclusão sempre exige sua escolha.", 11, MUTED, false);
        LinearLayout.LayoutParams footerLp = new LinearLayout.LayoutParams(0, -2, 1f);
        footerLp.leftMargin = ui.dp(8);
        footer.addView(footerText, footerLp);
        content.addView(footer, new LinearLayout.LayoutParams(-1, -2));

        ui.revealChildren(content);
    }

    private void addHomeHeader() {
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(ui.badge(R.drawable.ic_brand, ON_ACCENT_CONTAINER, ACCENT_CONTAINER, 32, 18),
                new LinearLayout.LayoutParams(ui.dp(56), ui.dp(56)));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titlesLp = new LinearLayout.LayoutParams(0, -2, 1f);
        titlesLp.leftMargin = ui.dp(14);
        head.addView(titles, titlesLp);
        TextView eyebrow = ui.text("CUIDADO COM SEU ARMAZENAMENTO", 10, ACCENT, true);
        eyebrow.setLetterSpacing(0.10f);
        titles.addView(eyebrow);
        TextView title = ui.text("Zelo", 34, TEXT, true);
        title.setLetterSpacing(-0.025f);
        titles.addView(title, margin(1));
        content.addView(head);
        LinearLayout.LayoutParams subLp = margin(12);
        subLp.bottomMargin = ui.dp(18);
        content.addView(ui.text("Entenda o que ocupa espaço e escolha o que merece ser revisado.", 14, MUTED, false), subLp);
    }

    private LinearLayout storageMetric(String label, String value) {
        LinearLayout metric = new LinearLayout(this);
        metric.setOrientation(LinearLayout.VERTICAL);
        metric.setPadding(ui.dp(13), ui.dp(11), ui.dp(13), ui.dp(11));
        metric.setBackground(ui.surfaceDrawable(SURFACE, 16));
        TextView caption = ui.text(label, 9, MUTED, true);
        caption.setLetterSpacing(0.08f);
        metric.addView(caption);
        TextView amount = ui.text(value, 15, TEXT, true);
        amount.setMaxLines(1);
        metric.addView(amount, margin(4));
        return metric;
    }

    private boolean isLightTheme() {
        String mode = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_THEME_MODE, "system");
        if ("light".equals(mode)) return true;
        if ("dark".equals(mode)) return false;
        int night = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
        return night != android.content.res.Configuration.UI_MODE_NIGHT_YES;
    }

    private void renderAppearance() {
        showShell();
        showingAppearance = true;
        addTopBar("Aparência");
        LinearLayout.LayoutParams introLp = margin(18);
        introLp.bottomMargin = ui.dp(16);
        content.addView(ui.text("Ajuste a experiência visual do Zelo ao seu jeito.", 14, MUTED, false), introLp);

        LinearLayout modeCard = ui.card();
        modeCard.addView(ui.text("Tema do aplicativo", 16, TEXT, true));
        modeCard.addView(ui.text("Escolha como o Zelo acompanha a aparência do aparelho.", 12, MUTED, false), margin(4));
        String selected = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_THEME_MODE, "system");
        LinearLayout options = new LinearLayout(this);
        options.setOrientation(LinearLayout.HORIZONTAL);
        options.setBaselineAligned(false);
        String[] labels = {"Sistema", "Claro", "Escuro"};
        String[] values = {"system", "light", "dark"};
        int[] icons = {R.drawable.ic_phone, R.drawable.ic_light, R.drawable.ic_dark};
        for (int i = 0; i < labels.length; i++) {
            LinearLayout.LayoutParams optLp = new LinearLayout.LayoutParams(0, -2, 1f);
            if (i > 0) optLp.leftMargin = ui.dp(8);
            options.addView(themeOption(labels[i], icons[i], values[i].equals(selected), values[i]), optLp);
        }
        modeCard.addView(options, margin(14));
        addCard(modeCard);

        LinearLayout dynamicCard = ui.card();
        LinearLayout dynamicHeader = new LinearLayout(this);
        dynamicHeader.setOrientation(LinearLayout.HORIZONTAL);
        dynamicHeader.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout dynamicText = new LinearLayout(this);
        dynamicText.setOrientation(LinearLayout.VERTICAL);
        dynamicText.addView(ui.text("Cores dinâmicas", 16, TEXT, true));
        dynamicText.addView(ui.text("Material You", 12, ACCENT, true), margin(3));
        dynamicHeader.addView(dynamicText, new LinearLayout.LayoutParams(0, -2, 1f));
        MaterialSwitch dynamicSwitch = new MaterialSwitch(this);
        boolean dynamicEnabled = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(PREF_DYNAMIC_COLORS, true);
        dynamicSwitch.setChecked(dynamicEnabled);
        dynamicSwitch.setEnabled(Build.VERSION.SDK_INT >= 31);
        dynamicHeader.addView(dynamicSwitch, new LinearLayout.LayoutParams(-2, -2));
        dynamicCard.addView(dynamicHeader);
        String explanation = Build.VERSION.SDK_INT >= 31
                ? "Quando ativado, o Zelo usa a paleta do papel de parede e as cores do sistema Android 12 ou superior."
                : "As cores dinâmicas do Material You exigem Android 12 ou superior. O tema escolhido continua disponível neste aparelho.";
        dynamicCard.addView(ui.text(explanation, 12, MUTED, false), margin(10));
        dynamicSwitch.setOnCheckedChangeListener((button, checked) -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean(PREF_DYNAMIC_COLORS, checked).apply();
            recreate();
        });
        addCard(dynamicCard);

        LinearLayout preview = ui.card();
        preview.addView(ui.text("Prévia da paleta", 14, TEXT, true));
        LinearLayout swatches = new LinearLayout(this);
        swatches.setOrientation(LinearLayout.HORIZONTAL);
        int[] colors = {ACCENT, SECONDARY, ACCENT_CONTAINER, WARNING_CONTAINER, DANGER};
        for (int color : colors) {
            View swatch = new View(this);
            swatch.setBackground(ui.rounded(color, 12));
            LinearLayout.LayoutParams swatchLp = new LinearLayout.LayoutParams(0, ui.dp(34), 1f);
            swatchLp.leftMargin = ui.dp(3);
            swatchLp.rightMargin = ui.dp(3);
            swatches.addView(swatch, swatchLp);
        }
        preview.addView(swatches, margin(12));
        preview.addView(ui.text("As cores são aplicadas também aos cartões, indicadores, botões e telas de resultados.", 11, MUTED, false), margin(8));
        addCard(preview);
        ui.revealChildren(content);
    }

    /** Opção de tema: cartão com ícone e rótulo; a escolhida fica destacada. */
    private View themeOption(String label, int iconRes, boolean selected, String value) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(ui.dp(8), ui.dp(14), ui.dp(8), ui.dp(12));
        box.setBackground(ui.rippleSurface(selected ? ACCENT_CONTAINER : CARD_ALT, 18));
        int fg = selected ? ON_ACCENT_CONTAINER : MUTED;
        box.addView(ui.icon(iconRes, fg), new LinearLayout.LayoutParams(ui.dp(26), ui.dp(26)));
        TextView t = ui.text(label, 13, selected ? ON_ACCENT_CONTAINER : TEXT, selected);
        t.setGravity(Gravity.CENTER);
        box.addView(t, margin(8));
        box.setClickable(true);
        box.setFocusable(true);
        box.setContentDescription("Tema: " + label + (selected ? " (selecionado)" : ""));
        box.setOnClickListener(v -> {
            if (selected) return;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_THEME_MODE, value).apply();
            recreate();
        });
        return box;
    }

    private LinearLayout.LayoutParams margin(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = ui.dp(topDp);
        return lp;
    }

    private void addSectionLabel(String label) {
        TextView t = ui.text(label, 15, TEXT, true);
        LinearLayout.LayoutParams lp = margin(20);
        lp.bottomMargin = ui.dp(10);
        content.addView(t, lp);
    }

    /** Barra superior com botão de voltar e título. */
    private void addTopBar(String title) {
        content.addView(ui.topBar(title, this::handleBack), new LinearLayout.LayoutParams(-1, -2));
    }

    private void addToolRow(View left, View right) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setBaselineAligned(false);
        LinearLayout.LayoutParams leftLp = new LinearLayout.LayoutParams(0, -1, 1f);
        leftLp.rightMargin = ui.dp(5);
        LinearLayout.LayoutParams rightLp = new LinearLayout.LayoutParams(0, -1, 1f);
        rightLp.leftMargin = ui.dp(5);
        row.addView(left, leftLp);
        row.addView(right, rightLp);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, -2);
        rowLp.bottomMargin = ui.dp(10);
        content.addView(row, rowLp);
    }

    private View toolTile(int iconRes, String title, String subtitle, int badgeBg, int badgeFg, Runnable action) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setPadding(ui.dp(16), ui.dp(16), ui.dp(14), ui.dp(16));
        tile.setBackground(ui.rippleSurface(CARD, 22));
        tile.addView(ui.badge(iconRes, badgeFg, badgeBg, 24, 16), new LinearLayout.LayoutParams(ui.dp(46), ui.dp(46)));
        TextView t = ui.text(title, 14, TEXT, true);
        t.setGravity(Gravity.START);
        tile.addView(t, margin(14));
        TextView sub = ui.text(subtitle, 11, MUTED, false);
        sub.setGravity(Gravity.START);
        sub.setMaxLines(3);
        tile.addView(sub, margin(3));
        tile.setClickable(true);
        tile.setFocusable(true);
        tile.setOnClickListener(v -> action.run());
        return tile;
    }

    private void addAction(int iconRes, String title, String subtitle, int badgeBg, int badgeFg, Runnable action) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(ui.dp(16), ui.dp(14), ui.dp(12), ui.dp(14));
        tile.setBackground(ui.rippleSurface(CARD, 22));
        tile.addView(ui.badge(iconRes, badgeFg, badgeBg, 24, 16), new LinearLayout.LayoutParams(ui.dp(48), ui.dp(48)));
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams bodyLp = new LinearLayout.LayoutParams(0, -2, 1f);
        bodyLp.leftMargin = ui.dp(14);
        bodyLp.rightMargin = ui.dp(6);
        tile.addView(body, bodyLp);
        body.addView(ui.text(title, 15, TEXT, true));
        body.addView(ui.text(subtitle, 12, MUTED, false), margin(3));
        tile.addView(ui.icon(R.drawable.ic_chevron_right, MUTED), new LinearLayout.LayoutParams(ui.dp(24), ui.dp(24)));
        LinearLayout.LayoutParams tileLp = new LinearLayout.LayoutParams(-1, -2);
        tileLp.bottomMargin = ui.dp(10);
        content.addView(tile, tileLp);
        tile.setClickable(true);
        tile.setFocusable(true);
        tile.setOnClickListener(v -> action.run());
    }

    private void addCard(View view) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = ui.dp(12);
        content.addView(view, lp);
    }

    // ---------- pasta ----------

    private void chooseFolder() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, REQUEST_FOLDER);
        } catch (Exception e) {
            new MaterialAlertDialogBuilder(this)
                    .setTitle("Seletor indisponível")
                    .setMessage("Não foi possível abrir o seletor de pastas deste aparelho.")
                    .setPositiveButton("OK", null).show();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_FOLDER || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri picked = data.getData();
        int grantFlags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try {
            getContentResolver().takePersistableUriPermission(picked, grantFlags);
        } catch (SecurityException ignored) {
            // Alguns provedores não oferecem permissão persistente; a pasta ainda pode funcionar na sessão atual.
        }
        folderUri = picked;
        DocumentFile root = DocumentFile.fromTreeUri(this, folderUri);
        folderName = root != null && root.getName() != null ? root.getName() : "Pasta selecionada";
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_TREE_URI, folderUri.toString()).apply();
        Toast.makeText(this, "Pasta selecionada: " + folderName, Toast.LENGTH_SHORT).show();
        renderHome();
    }

    // ---------- análise ----------

    // ---------- fonte de análise ----------

    private String sourceLabel() {
        switch (sourceType) {
            case DIRECT: return "Armazenamento interno";
            case SHIZUKU: return "Android/data e obb";
            default: return folderName;
        }
    }

    private void chooseSource() {
        SourceType[] types = SourceType.values();
        String[] labels = new String[types.length];
        int checked = 0;
        for (int i = 0; i < types.length; i++) {
            labels[i] = types[i].label;
            if (types[i] == sourceType) checked = i;
        }
        new MaterialAlertDialogBuilder(this)
                .setTitle("Fonte de análise")
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    dialog.dismiss();
                    SourceType picked = types[which];
                    sourceType = picked;
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_SOURCE, picked.name()).apply();
                    renderHome();
                    new MaterialAlertDialogBuilder(this).setTitle(picked.label).setMessage(picked.description)
                            .setPositiveButton("OK", null).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /** Valida o que a fonte atual exige (pasta escolhida, permissão ou Shizuku) e entrega a fonte pronta. */
    private void withSource(Consumer<FileSource> action) {
        switch (sourceType) {
            case DIRECT:
                if (Build.VERSION.SDK_INT < 30) {
                    new MaterialAlertDialogBuilder(this).setTitle("Indisponível neste Android")
                            .setMessage("O modo de armazenamento completo exige Android 11 ou superior. Use \"Pasta escolhida\".")
                            .setPositiveButton("OK", null).show();
                } else if (!Environment.isExternalStorageManager()) {
                    askAllFilesAccess();
                } else {
                    action.accept(new DirectSource(this, Environment.getExternalStorageDirectory()));
                }
                return;
            case SHIZUKU:
                shizuku.ensureReady(service -> action.accept(new ShizukuSource(service)));
                return;
            case SAF:
            default:
                if (folderUri == null) {
                    new MaterialAlertDialogBuilder(this)
                            .setTitle("Escolha uma pasta primeiro")
                            .setMessage("Por segurança, o Zelo só analisa os arquivos de uma pasta escolhida por você. O seletor do Android também pode bloquear pastas protegidas, como Android/data.")
                            .setNegativeButton("Agora não", null)
                            .setPositiveButton("Escolher pasta", (d, w) -> chooseFolder())
                            .show();
                    return;
                }
                DocumentFile root = DocumentFile.fromTreeUri(this, folderUri);
                if (root == null || !root.canRead()) {
                    new MaterialAlertDialogBuilder(this).setTitle("Acesso à pasta expirou")
                            .setMessage("Escolha a pasta novamente para conceder acesso ao Zelo.")
                            .setPositiveButton("Escolher pasta", (d, w) -> chooseFolder()).setNegativeButton("Cancelar", null).show();
                    return;
                }
                action.accept(new SafSource(getContentResolver(), folderUri, folderName));
        }
    }

    private void askAllFilesAccess() {
        new MaterialAlertDialogBuilder(this)
                .setTitle("Permitir acesso a todos os arquivos")
                .setMessage("Para analisar o armazenamento completo, o Android pede que você ative \"Acesso a todos os arquivos\" para o Zelo. "
                        + "O app continua sem internet. A permissão pode ser removida a qualquer momento nas configurações. Depois de ativar, volte e toque na ferramenta de novo.")
                .setNegativeButton("Agora não", null)
                .setPositiveButton("Abrir configuração", (d, w) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                Uri.parse("package:" + getPackageName())));
                    } catch (Exception e) {
                        try { startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)); }
                        catch (Exception ignored) { }
                    }
                })
                .show();
    }

    // ---------- análise ----------

    private void startScan(ScanMode mode) {
        if (scanning || deleting) return;
        withSource(source -> runScan(source, mode));
    }

    private void runScan(FileSource source, ScanMode mode) {
        scanning = true;
        activeSource = source;
        if (mode.streaming()) {
            showResults(mode);
            results.begin();
        } else {
            renderLoading("Analisando arquivos", "Modo: " + mode.title + "\nFonte: " + source.label(), true);
        }
        scanner.start(source, mode, new ScanController.Callbacks() {
            @Override public void onProgress(int scanned) {
                if (results != null) results.setProgress(scanned);
                else if (liveProgress != null) liveProgress.setText("Arquivos examinados: " + scanned);
            }

            @Override public void onStage(String text) {
                if (liveProgress != null) liveProgress.setText(text);
            }

            @Override public void onBatch(List<ScanFile> batch) {
                if (results != null) results.addBatch(batch);
            }

            @Override public void onFinished(int scanned, boolean truncated, List<DuplicateGroup> groups) {
                scanning = false;
                if (results == null) {
                    showResults(mode);
                    results.begin();
                }
                results.finish(scanned, truncated, groups);
            }

            @Override public void onError() {
                scanning = false;
                renderMessage("Não foi possível analisar",
                        "Não foi possível concluir a análise. O provedor de arquivos pode ter bloqueado parte da pasta.", true);
            }
        });
    }

    // ---------- resumo de espaço e apps ----------

    private void startSpaceSummary() {
        if (scanning || deleting) return;
        withSource(source -> runSummary(source, "Resumo do espaço", 2, 20, (summary, scanned, truncated) -> {
            renderPage("Resumo do espaço", "Fonte: " + source.label() + " · " + scanned + " arquivos examinados", page ->
                    SummaryViews.addSpace(page, ui, this, summary, scanned, truncated));
        }));
    }

    /** Ranking de apps: sempre usa o Shizuku, sem mudar a fonte escolhida para as outras ferramentas. */
    private void startAppRanking() {
        if (scanning || deleting) return;
        shizuku.ensureReady(service -> {
            FileSource source = new ShizukuSource(service);
            runSummary(source, "Apps por espaço", 2, Integer.MAX_VALUE, (summary, scanned, truncated) -> {
                List<AppSpaceRanker.AppSpace> ranking = AppSpaceRanker.rank(summary.folders);
                renderPage("Apps por espaço", ranking.size() + " apps com dados em Android/data ou obb", page ->
                        SummaryViews.addApps(page, ui, this, ranking));
            });
        });
    }

    private interface SummaryDone {
        void done(SpaceSummary summary, int scanned, boolean truncated);
    }

    private void runSummary(FileSource source, String title, int folderDepth, int maxFolders, SummaryDone done) {
        scanning = true;
        renderLoading(title, "Fonte: " + source.label(), true);
        scanner.summarize(source, folderDepth, maxFolders, new ScanController.SummaryCallbacks() {
            @Override public void onProgress(int scanned) {
                if (liveProgress != null) liveProgress.setText("Arquivos examinados: " + scanned);
            }

            @Override public void onDone(SpaceSummary summary, int scanned, boolean truncated) {
                scanning = false;
                done.done(summary, scanned, truncated);
            }

            @Override public void onError() {
                scanning = false;
                renderMessage("Não foi possível analisar", "A fonte de arquivos não respondeu. Tente novamente.", true);
            }
        });
    }

    private void renderPage(String title, String subtitle, Consumer<LinearLayout> body) {
        showShell();
        addTopBar(title);
        content.addView(ui.text(subtitle, 12, MUTED, false), margin(10));
        body.accept(content);
        ui.revealChildren(content);
    }

    // ---------- limpeza de caches (Shizuku) ----------

    private void trimCaches() {
        if (scanning || deleting) return;
        shizuku.ensureReady(service -> new MaterialAlertDialogBuilder(this)
                .setTitle("Limpar caches dos apps?")
                .setMessage("O Zelo pede ao sistema (pm trim-caches) que libere os caches dos apps. "
                        + "Os dados dos apps não são apagados, mas apps podem demorar mais para abrir na próxima vez. "
                        + "O resultado depende da versão do Android e do fabricante.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Limpar", (d, w) -> {
                    deleting = true;
                    deleteDialog = new MaterialAlertDialogBuilder(this).setTitle("Limpando caches")
                            .setMessage("Aguarde, isso pode levar alguns instantes…").setCancelable(false).show();
                    ioWorker.execute(() -> {
                        long before = freeBytes();
                        String output;
                        try {
                            output = service.trimCaches(totalBytes());
                        } catch (Exception e) {
                            output = "erro: " + e.getMessage();
                        }
                        final long after = freeBytes();
                        final String finalOutput = output;
                        mainHandler.post(() -> {
                            deleting = false;
                            if (deleteDialog != null) { deleteDialog.dismiss(); deleteDialog = null; }
                            long gained = Math.max(0, after - before);
                            new MaterialAlertDialogBuilder(this).setTitle("Limpeza de caches concluída")
                                    .setMessage("Espaço livre ganho: " + app.zelo.limpeza.util.Formatters.formatBytes(gained, java.util.Locale.getDefault())
                                            + "\n\nResposta do sistema: " + finalOutput.trim())
                                    .setPositiveButton("OK", (x, y) -> renderHome()).show();
                        });
                    });
                })
                .show());
    }

    private long freeBytes() {
        try { return new StatFs(Environment.getDataDirectory().getAbsolutePath()).getAvailableBytes(); }
        catch (Exception e) { return 0; }
    }

    private long totalBytes() {
        try { return new StatFs(Environment.getDataDirectory().getAbsolutePath()).getTotalBytes(); }
        catch (Exception e) { return Long.MAX_VALUE / 4; }
    }

    private void showResults(ScanMode mode) {
        disposeResults();
        results = new ResultsScreen(this, ui, this, mode, activeSource, sourceLabel());
        showingAppearance = false;
        setContentView(results.root());
        applyInsets(results.root());
        setOnHome(false);
    }

    private void renderLoading(String title, String message, boolean cancellable) {
        showShell();
        addTopBar(title);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(ui.dp(8), ui.dp(48), ui.dp(8), ui.dp(24));
        CircularProgressIndicator progress = new CircularProgressIndicator(this);
        progress.setIndeterminate(true);
        progress.setIndicatorSize(ui.dp(64));
        progress.setTrackThickness(ui.dp(6));
        progress.setIndicatorColor(ACCENT);
        progress.setTrackColor(CARD_ALT);
        box.addView(progress, new LinearLayout.LayoutParams(ui.dp(64), ui.dp(64)));
        TextView msg = ui.text(message, 14, MUTED, false);
        msg.setGravity(Gravity.CENTER);
        box.addView(msg, margin(24));
        liveProgress = ui.text("", 13, ACCENT, true);
        liveProgress.setGravity(Gravity.CENTER);
        box.addView(liveProgress, margin(10));
        content.addView(box, new LinearLayout.LayoutParams(-1, -2));
        if (cancellable) {
            MaterialButton cancel = ui.button("Cancelar análise", CARD_ALT, TEXT, R.drawable.ic_stop, false);
            content.addView(cancel, new LinearLayout.LayoutParams(-1, ui.dp(48)));
            cancel.setOnClickListener(v -> handleBack());
        }
        ui.revealChildren(content);
    }

    private void renderMessage(String title, String message, boolean error) {
        showShell();
        addTopBar("Zelo");
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(ui.dp(8), ui.dp(40), ui.dp(8), ui.dp(8));
        box.addView(ui.badge(error ? R.drawable.ic_warning : R.drawable.ic_info,
                        error ? ON_DANGER_CONTAINER : ON_ACCENT_CONTAINER,
                        error ? DANGER_CONTAINER : ACCENT_CONTAINER, 32, 28),
                new LinearLayout.LayoutParams(ui.dp(64), ui.dp(64)));
        TextView t = ui.text(title, 22, error ? DANGER : ACCENT, true);
        t.setGravity(Gravity.CENTER);
        box.addView(t, margin(18));
        TextView m = ui.text(message, 15, TEXT, false);
        m.setGravity(Gravity.CENTER);
        box.addView(m, margin(10));
        content.addView(box, new LinearLayout.LayoutParams(-1, -2));
        MaterialButton home = ui.button("Voltar ao início", ACCENT, BG, R.drawable.ic_arrow_back, false);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(-1, ui.dp(50));
        hlp.topMargin = ui.dp(20);
        content.addView(home, hlp);
        home.setOnClickListener(v -> renderHome());
        ui.revealChildren(content);
    }

    // ---------- ResultsScreen.Host ----------

    @Override
    public void onBack() {
        handleBack();
    }

    @Override
    public void onStopScan() {
        stopRunningScan();
    }

    /** Ao sair do app durante uma análise, ela é interrompida e o que já chegou é mantido como parcial. */
    @Override
    protected void onStop() {
        super.onStop();
        stopRunningScan();
    }

    private void stopRunningScan() {
        if (results == null || !results.isRunning()) return;
        scanner.cancel();
        scanning = false;
        results.markStopped();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(STATE_APPEARANCE, showingAppearance);
    }

    @Override
    public void onOpen(ScanFile file) {
        if (activeSource != null) FileActions.open(this, activeSource, file);
    }

    @Override
    public void onShare(ScanMode mode, int scanned, List<ScanFile> files) {
        FileActions.share(this, mode, sourceLabel(), scanned, files);
    }

    @Override
    public void onDelete(List<ScanFile> selected) {
        if (deleting || activeSource == null || results == null) return;
        deleting = true;
        final FileSource source = activeSource;
        final ResultsScreen screen = results;
        deleteDialog = new MaterialAlertDialogBuilder(this)
                .setTitle("Excluindo arquivos")
                .setMessage("O Zelo tentará excluir somente os itens marcados por você.")
                .setCancelable(false)
                .show();
        ioWorker.execute(() -> {
            FileActions.DeleteOutcome out = FileActions.delete(source, selected);
            mainHandler.post(() -> {
                deleting = false;
                if (deleteDialog != null) {
                    deleteDialog.dismiss();
                    deleteDialog = null;
                }
                if (results != screen) return; // a pessoa já saiu da tela
                screen.removeDeleted(out.deleted);
                StringBuilder msg = new StringBuilder();
                msg.append("Excluídos: ").append(out.deleted.size())
                        .append("\nFalhas: ").append(out.failedPaths.size())
                        .append("\nTamanho informado dos itens excluídos: ")
                        .append(app.zelo.limpeza.util.Formatters.formatBytes(out.freedBytes, java.util.Locale.getDefault()));
                if (!out.failedPaths.isEmpty()) {
                    msg.append("\n\nNão foi possível excluir:");
                    int shown = Math.min(out.failedPaths.size(), MAX_FAILURES_SHOWN);
                    for (int i = 0; i < shown; i++) msg.append("\n• ").append(out.failedPaths.get(i));
                    if (out.failedPaths.size() > shown) msg.append("\n… e mais ").append(out.failedPaths.size() - shown);
                }
                new MaterialAlertDialogBuilder(this).setTitle("Exclusão concluída").setMessage(msg.toString())
                        .setPositiveButton("OK", null).show();
            });
        });
    }

    private void openAppSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS));
        } catch (Exception e) {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) { }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (deleteDialog != null) deleteDialog.dismiss();
        disposeResults();
        shizuku.release();
        scanner.shutdown();
        mainHandler.removeCallbacksAndMessages(null);
        ioWorker.shutdown(); // deixa terminar uma exclusão já iniciada
    }
}
