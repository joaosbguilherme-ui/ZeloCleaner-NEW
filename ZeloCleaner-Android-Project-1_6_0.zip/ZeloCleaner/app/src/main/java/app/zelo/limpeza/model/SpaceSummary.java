package app.zelo.limpeza.model;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/** Resultado do resumo de espaço: totais por categoria e pastas que mais ocupam. */
public final class SpaceSummary {
    public static final class Total {
        public long bytes;
        public int count;
    }

    public static final class FolderTotal {
        public final String path;
        public final long bytes;
        public final int count;

        public FolderTotal(String path, long bytes, int count) {
            this.path = path;
            this.bytes = bytes;
            this.count = count;
        }
    }

    public final long totalBytes;
    public final int totalFiles;
    public final Map<FileCategory, Total> categories = new EnumMap<>(FileCategory.class);
    public final List<FolderTotal> folders = new ArrayList<>();

    public SpaceSummary(long totalBytes, int totalFiles) {
        this.totalBytes = totalBytes;
        this.totalFiles = totalFiles;
        for (FileCategory c : FileCategory.values()) categories.put(c, new Total());
    }
}
