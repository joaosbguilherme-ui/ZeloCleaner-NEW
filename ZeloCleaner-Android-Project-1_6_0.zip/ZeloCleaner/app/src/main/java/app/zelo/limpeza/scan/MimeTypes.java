package app.zelo.limpeza.scan;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** Tipo MIME por extensão, sem depender do Android (usado nas fontes que listam arquivos direto). */
public final class MimeTypes {
    private static final Map<String, String> BY_EXT = new HashMap<>();

    static {
        for (String e : new String[]{"jpg", "jpeg"}) BY_EXT.put(e, "image/jpeg");
        BY_EXT.put("png", "image/png");
        BY_EXT.put("gif", "image/gif");
        BY_EXT.put("webp", "image/webp");
        BY_EXT.put("heic", "image/heic");
        BY_EXT.put("heif", "image/heif");
        BY_EXT.put("bmp", "image/bmp");
        BY_EXT.put("mp4", "video/mp4");
        BY_EXT.put("mkv", "video/x-matroska");
        BY_EXT.put("webm", "video/webm");
        BY_EXT.put("3gp", "video/3gpp");
        BY_EXT.put("mov", "video/quicktime");
        BY_EXT.put("avi", "video/x-msvideo");
        BY_EXT.put("mp3", "audio/mpeg");
        BY_EXT.put("m4a", "audio/mp4");
        BY_EXT.put("aac", "audio/aac");
        BY_EXT.put("ogg", "audio/ogg");
        BY_EXT.put("opus", "audio/opus");
        BY_EXT.put("wav", "audio/x-wav");
        BY_EXT.put("flac", "audio/flac");
        BY_EXT.put("amr", "audio/amr");
        BY_EXT.put("pdf", "application/pdf");
        BY_EXT.put("txt", "text/plain");
        BY_EXT.put("log", "text/plain");
        BY_EXT.put("csv", "text/csv");
        BY_EXT.put("html", "text/html");
        BY_EXT.put("json", "application/json");
        BY_EXT.put("zip", "application/zip");
        BY_EXT.put("apk", "application/vnd.android.package-archive");
        BY_EXT.put("doc", "application/msword");
        BY_EXT.put("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        BY_EXT.put("xls", "application/vnd.ms-excel");
        BY_EXT.put("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        BY_EXT.put("ppt", "application/vnd.ms-powerpoint");
        BY_EXT.put("pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation");
    }

    private MimeTypes() { }

    public static String extension(String name) {
        int dot = name.lastIndexOf('.');
        return dot < 0 || dot == name.length() - 1 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    public static String guess(String name) {
        String mime = BY_EXT.get(extension(name));
        return mime != null ? mime : "application/octet-stream";
    }
}
