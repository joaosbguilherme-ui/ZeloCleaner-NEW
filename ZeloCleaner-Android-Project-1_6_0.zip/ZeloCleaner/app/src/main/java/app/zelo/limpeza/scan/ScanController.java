package app.zelo.limpeza.scan;

import android.os.Handler;
import android.os.Looper;

import app.zelo.limpeza.model.DuplicateGroup;
import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.model.ScanMode;
import app.zelo.limpeza.model.SpaceSummary;
import app.zelo.limpeza.source.FileSource;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Executa a análise em segundo plano e entrega resultados em lotes na thread principal.
 * Cancelar invalida a execução atual: nada mais é entregue depois disso.
 */
public final class ScanController {
    private static final long FLUSH_INTERVAL_MS = 300L;
    private static final int FLUSH_BATCH = 250;

    public interface Callbacks {
        /** Quantidade de arquivos examinados até agora. */
        void onProgress(int scanned);

        /** Texto de etapa, usado na comparação de duplicados. */
        void onStage(String text);

        /** Novos resultados (modos que mostram resultados durante a varredura). */
        void onBatch(List<ScanFile> batch);

        /** Fim da análise. {@code groups} é preenchido só no modo de duplicados. */
        void onFinished(int scanned, boolean truncated, List<DuplicateGroup> groups);

        void onError();
    }

    public interface SummaryCallbacks {
        void onProgress(int scanned);

        void onDone(SpaceSummary summary, int scanned, boolean truncated);

        void onError();
    }

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final AtomicInteger generation = new AtomicInteger();

    public void cancel() {
        generation.incrementAndGet();
    }

    public void shutdown() {
        cancel();
        main.removeCallbacksAndMessages(null);
        worker.shutdownNow();
    }

    /** Resumo de espaço por categoria e pasta. */
    public void summarize(FileSource source, int folderDepth, int maxFolders, SummaryCallbacks cb) {
        final int token = generation.incrementAndGet();
        worker.execute(() -> {
            try {
                SpaceAnalyzer analyzer = new SpaceAnalyzer(folderDepth);
                final long[] last = {System.currentTimeMillis()};
                final int[] count = {0};
                TreeWalker.Summary summary = source.scan(() -> cancelled(token), file -> {
                    analyzer.add(file);
                    count[0]++;
                    long t = System.currentTimeMillis();
                    if (t - last[0] >= FLUSH_INTERVAL_MS) {
                        last[0] = t;
                        final int n = count[0];
                        post(token, () -> cb.onProgress(n));
                    }
                });
                if (cancelled(token)) return;
                SpaceSummary result = analyzer.result(maxFolders);
                post(token, () -> cb.onDone(result, summary.scanned, summary.truncated));
            } catch (Exception e) {
                post(token, cb::onError);
            }
        });
    }

    public void start(FileSource source, ScanMode mode, Callbacks cb) {
        final int token = generation.incrementAndGet();
        worker.execute(() -> {
            try {
                run(source, mode, cb, token);
            } catch (Exception e) {
                post(token, cb::onError);
            }
        });
    }

    private boolean cancelled(int token) {
        return generation.get() != token || Thread.currentThread().isInterrupted();
    }

    private void post(int token, Runnable r) {
        main.post(() -> {
            if (generation.get() == token) r.run();
        });
    }

    private void run(FileSource source, ScanMode mode, Callbacks cb, int token) {
        final long now = System.currentTimeMillis();
        final List<ScanFile> collected = new ArrayList<>();   // todos (duplicados) ou pendentes de envio (demais)
        final long[] lastFlush = {System.currentTimeMillis()};
        final int[] count = {0};

        TreeWalker.Summary summary = source.scan(() -> cancelled(token), file -> {
            count[0]++;
            if (mode == ScanMode.DUPLICATES) {
                if (file.size > 0) collected.add(file);
            } else {
                String reason = FileClassifier.reasonFor(mode, file, now);
                if (reason != null) {
                    file.reason = reason;
                    collected.add(file);
                }
            }
            long t = System.currentTimeMillis();
            boolean due = t - lastFlush[0] >= FLUSH_INTERVAL_MS;
            if (due || (mode.streaming() && collected.size() >= FLUSH_BATCH)) {
                lastFlush[0] = t;
                final int scannedNow = count[0];
                post(token, () -> cb.onProgress(scannedNow));
                if (mode.streaming() && !collected.isEmpty()) {
                    final List<ScanFile> batch = new ArrayList<>(collected);
                    collected.clear();
                    post(token, () -> cb.onBatch(batch));
                }
            }
        });
        if (cancelled(token)) return;

        if (mode.streaming()) {
            if (!collected.isEmpty()) {
                final List<ScanFile> batch = new ArrayList<>(collected);
                post(token, () -> cb.onBatch(batch));
            }
            post(token, () -> cb.onFinished(summary.scanned, summary.truncated, null));
            return;
        }

        post(token, () -> cb.onStage("Comparando o conteúdo de " + collected.size() + " arquivos…"));
        List<DuplicateGroup> groups = DuplicateFinder.find(collected, source,
                () -> cancelled(token),
                (done, total) -> {
                    if (done % 5 == 0 || done == total) {
                        post(token, () -> cb.onStage("Comparando arquivos: " + done + " de " + total));
                    }
                });
        if (cancelled(token)) return;
        post(token, () -> cb.onFinished(summary.scanned, summary.truncated, groups));
    }
}
