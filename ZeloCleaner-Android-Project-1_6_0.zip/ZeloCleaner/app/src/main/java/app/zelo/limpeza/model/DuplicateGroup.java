package app.zelo.limpeza.model;

import java.util.ArrayList;
import java.util.List;

/** Um conjunto de arquivos idênticos: o original (mais antigo) é mantido; as cópias são sugeridas para revisão. */
public final class DuplicateGroup {
    public final ScanFile original;
    public final List<ScanFile> copies;

    public DuplicateGroup(ScanFile original, List<ScanFile> copies) {
        this.original = original;
        this.copies = new ArrayList<>(copies);
    }

    public long wastedBytes() {
        long total = 0;
        for (ScanFile f : copies) total += f.size;
        return total;
    }
}
