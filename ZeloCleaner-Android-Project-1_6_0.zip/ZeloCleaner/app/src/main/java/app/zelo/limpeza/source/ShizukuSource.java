package app.zelo.limpeza.source;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;

import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.scan.EntryCodec;
import app.zelo.limpeza.scan.TreeWalker;
import app.zelo.limpeza.shizuku.FileService;
import app.zelo.limpeza.shizuku.IFileService;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Android/data e Android/obb, lidos por um serviço que roda com a permissão de shell concedida pelo Shizuku. */
public final class ShizukuSource implements FileSource {
    private static final int PAGE = 1500;

    private final IFileService service;

    public ShizukuSource(IFileService service) {
        this.service = service;
    }

    @Override public String label() { return "Android/data e obb"; }

    private List<TreeWalker.Entry> list(String dirId) throws IOException {
        List<TreeWalker.Entry> out = new ArrayList<>();
        try {
            int offset = 0;
            while (true) {
                String[] page = service.listDir(dirId, offset, PAGE);
                if (page == null) throw new IOException("pasta não permitida");
                for (String line : page) {
                    TreeWalker.Entry e = EntryCodec.decode(dirId, line);
                    if (e == null) continue;
                    // Na raiz "Android", só entram "data" e "obb".
                    if (dirId.equals(FileService.ANDROID_ROOT) && !e.name.equals("data") && !e.name.equals("obb")) continue;
                    out.add(e);
                }
                if (page.length < PAGE) break;
                offset += PAGE;
            }
        } catch (RemoteException e) {
            throw new IOException(e);
        }
        return out;
    }

    @Override
    public TreeWalker.Summary scan(BooleanSupplier cancelled, Consumer<ScanFile> onFile) {
        return TreeWalker.walk(this::list, FileService.ANDROID_ROOT, cancelled, onFile);
    }

    @Override
    public InputStream open(ScanFile file) throws IOException {
        try {
            ParcelFileDescriptor pfd = service.openRead(file.documentId);
            if (pfd == null) throw new IOException("sem acesso");
            return new ParcelFileDescriptor.AutoCloseInputStream(pfd);
        } catch (RemoteException e) {
            throw new IOException(e);
        }
    }

    @Override
    public boolean delete(ScanFile file) {
        try {
            return service.deleteFile(file.documentId);
        } catch (Exception e) {
            return false;
        }
    }

    /** Outros apps não conseguem abrir arquivos de Android/data. */
    @Override public Uri viewUri(ScanFile file) { return null; }

    @Override public Bitmap thumbnail(ScanFile file, int sizePx) { return null; }
}
