package app.zelo.limpeza.ui;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.model.ScanMode;
import app.zelo.limpeza.scan.ReportBuilder;
import app.zelo.limpeza.source.FileSource;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Abrir, excluir e compartilhar arquivos encontrados. */
public final class FileActions {
    private FileActions() { }

    public static void open(Activity activity, FileSource source, ScanFile f) {
        Uri uri = source.viewUri(f);
        if (uri == null) {
            Toast.makeText(activity, "Este arquivo não pode ser aberto por outro app neste modo.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent view = new Intent(Intent.ACTION_VIEW);
        view.setDataAndType(uri, f.mimeType);
        view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            activity.startActivity(view);
        } catch (ActivityNotFoundException | SecurityException e) {
            Toast.makeText(activity, "Nenhum aplicativo consegue abrir este arquivo.", Toast.LENGTH_SHORT).show();
        }
    }

    public static final class DeleteOutcome {
        public final List<ScanFile> deleted = new ArrayList<>();
        public final List<String> failedPaths = new ArrayList<>();
        public long freedBytes;
    }

    /** Deve ser chamado fora da thread principal. */
    public static DeleteOutcome delete(FileSource source, List<ScanFile> files) {
        DeleteOutcome out = new DeleteOutcome();
        for (ScanFile f : files) {
            boolean ok;
            try {
                ok = source.delete(f);
            } catch (Exception e) {
                ok = false;
            }
            if (ok) {
                out.deleted.add(f);
                out.freedBytes += f.size;
            } else {
                out.failedPaths.add(f.relativePath);
            }
        }
        return out;
    }

    public static void share(Activity activity, ScanMode mode, String folderName, int scanned, List<ScanFile> found) {
        String text = ReportBuilder.build(mode, folderName,
                DateFormat.getDateTimeInstance().format(new Date()), scanned, found, Locale.getDefault());
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_SUBJECT, "Zelo — " + mode.title);
        send.putExtra(Intent.EXTRA_TEXT, text);
        try {
            activity.startActivity(Intent.createChooser(send, "Compartilhar lista"));
        } catch (Exception e) {
            Toast.makeText(activity, "Nenhum aplicativo disponível para compartilhar.", Toast.LENGTH_SHORT).show();
        }
    }
}
