package app.zelo.limpeza.scan;

import java.io.File;
import java.io.IOException;

/** Garante que operações destrutivas só atinjam caminhos dentro de uma raiz esperada. */
public final class PathGuard {
    private PathGuard() { }

    /** Verdadeiro se {@code path} está estritamente dentro de {@code root} (não é a própria raiz), resolvendo "..", e links. */
    public static boolean isStrictlyInside(String root, String path) {
        try {
            String r = new File(root).getCanonicalPath();
            String p = new File(path).getCanonicalPath();
            return p.length() > r.length() && p.startsWith(r.endsWith(File.separator) ? r : r + File.separator);
        } catch (IOException | RuntimeException e) {
            return false;
        }
    }

    public static boolean isStrictlyInsideAny(String path, String... roots) {
        for (String r : roots) if (isStrictlyInside(r, path)) return true;
        return false;
    }
}
