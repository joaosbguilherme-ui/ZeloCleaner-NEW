package app.zelo.limpeza.scan;

import app.zelo.limpeza.model.DuplicateGroup;
import app.zelo.limpeza.model.ScanFile;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.BooleanSupplier;

/**
 * Encontra arquivos idênticos: agrupa por tamanho, descarta diferentes pelo hash dos primeiros 64 KB
 * e confirma com o SHA-256 completo. Não depende do Android.
 */
public final class DuplicateFinder {
    public static final int QUICK_HASH_BYTES = 64 * 1024;

    public interface ContentSource {
        InputStream open(ScanFile file) throws IOException;
    }

    public interface Progress {
        void onProgress(int done, int total);
    }

    private DuplicateFinder() { }

    public static List<DuplicateGroup> find(List<ScanFile> files, ContentSource source,
                                            BooleanSupplier cancelled, Progress progress) {
        Map<Long, List<ScanFile>> bySize = new HashMap<>();
        for (ScanFile f : files) {
            if (f.size > 0) bySize.computeIfAbsent(f.size, k -> new ArrayList<>()).add(f);
        }
        int total = 0;
        for (List<ScanFile> g : bySize.values()) if (g.size() >= 2) total += g.size();

        List<DuplicateGroup> result = new ArrayList<>();
        int done = 0;
        for (Map.Entry<Long, List<ScanFile>> entry : bySize.entrySet()) {
            List<ScanFile> group = entry.getValue();
            if (group.size() < 2) continue;
            if (cancelled.getAsBoolean()) return result;
            long size = entry.getKey();

            Map<String, List<ScanFile>> byQuick = new HashMap<>();
            for (ScanFile f : group) {
                String quick = hash(source, f, QUICK_HASH_BYTES, cancelled);
                if (quick != null) byQuick.computeIfAbsent(quick, k -> new ArrayList<>()).add(f);
                done++;
                if (progress != null) progress.onProgress(done, total);
            }
            for (List<ScanFile> candidates : byQuick.values()) {
                if (candidates.size() < 2) continue;
                List<List<ScanFile>> identical = new ArrayList<>();
                if (size <= QUICK_HASH_BYTES) {
                    identical.add(candidates); // o hash parcial já cobriu o arquivo inteiro
                } else {
                    Map<String, List<ScanFile>> byFull = new HashMap<>();
                    for (ScanFile f : candidates) {
                        String full = hash(source, f, Long.MAX_VALUE, cancelled);
                        if (full != null) byFull.computeIfAbsent(full, k -> new ArrayList<>()).add(f);
                    }
                    identical.addAll(byFull.values());
                }
                for (List<ScanFile> same : identical) {
                    if (same.size() < 2) continue;
                    DuplicateGroup g = toGroup(same);
                    result.add(g);
                }
            }
        }
        return result;
    }

    /** A cópia mais antiga (data conhecida) é o original; as demais viram cópias. */
    static DuplicateGroup toGroup(List<ScanFile> same) {
        List<ScanFile> sorted = new ArrayList<>(same);
        Collections.sort(sorted, (x, y) -> {
            int c = Long.compare(x.modified > 0 ? x.modified : Long.MAX_VALUE, y.modified > 0 ? y.modified : Long.MAX_VALUE);
            return c != 0 ? c : x.relativePath.compareTo(y.relativePath);
        });
        ScanFile original = sorted.get(0);
        List<ScanFile> copies = new ArrayList<>(sorted.subList(1, sorted.size()));
        for (ScanFile c : copies) c.reason = "Idêntico a: " + original.relativePath;
        return new DuplicateGroup(original, copies);
    }

    /** SHA-256 dos primeiros {@code limit} bytes; null em falha de leitura ou cancelamento. */
    static String hash(ContentSource source, ScanFile file, long limit, BooleanSupplier cancelled) {
        try (InputStream raw = source.open(file)) {
            if (raw == null) return null;
            BufferedInputStream input = new BufferedInputStream(raw);
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[64 * 1024];
            long remaining = limit;
            while (remaining > 0) {
                if (cancelled.getAsBoolean()) return null;
                int read = input.read(buffer, 0, (int) Math.min(buffer.length, remaining));
                if (read == -1) break;
                digest.update(buffer, 0, read);
                remaining -= read;
            }
            StringBuilder hex = new StringBuilder();
            for (byte b : digest.digest()) hex.append(String.format(Locale.ROOT, "%02x", b & 0xff));
            return hex.toString();
        } catch (IOException | NoSuchAlgorithmException | RuntimeException e) {
            return null;
        }
    }
}
