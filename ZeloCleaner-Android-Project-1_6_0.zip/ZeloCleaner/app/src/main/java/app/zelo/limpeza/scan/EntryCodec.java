package app.zelo.limpeza.scan;

/** Formato de texto usado entre o app e o serviço do Shizuku: "d|f TAB tamanho TAB data TAB nome". */
public final class EntryCodec {
    private EntryCodec() { }

    public static String encode(String name, boolean directory, long size, long modified) {
        return (directory ? "d" : "f") + "\t" + size + "\t" + modified + "\t" + name;
    }

    /** Retorna null para linhas inválidas. */
    public static TreeWalker.Entry decode(String parentPath, String line) {
        if (line == null) return null;
        String[] parts = line.split("\t", 4);
        if (parts.length != 4 || parts[3].isEmpty()) return null;
        try {
            boolean dir = parts[0].equals("d");
            if (!dir && !parts[0].equals("f")) return null;
            long size = Long.parseLong(parts[1]);
            long modified = Long.parseLong(parts[2]);
            String parent = parentPath.endsWith("/") ? parentPath.substring(0, parentPath.length() - 1) : parentPath;
            return new TreeWalker.Entry(parent + "/" + parts[3], parts[3], dir, size, modified, null);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
