package app.zelo.limpeza.source;

public enum SourceType {
    SAF("Pasta escolhida", "Mais seguro: o Zelo só enxerga a pasta que você autorizar."),
    DIRECT("Armazenamento completo", "Analisa todo o armazenamento interno. Exige a permissão \"Acesso a todos os arquivos\"."),
    SHIZUKU("Android/data e obb (Shizuku)", "Modo avançado: enxerga as pastas de dados dos apps. Exige o Shizuku em execução.");

    public final String label;
    public final String description;

    SourceType(String label, String description) {
        this.label = label;
        this.description = description;
    }

    public static SourceType fromName(String name) {
        for (SourceType t : values()) if (t.name().equals(name)) return t;
        return SAF;
    }
}
