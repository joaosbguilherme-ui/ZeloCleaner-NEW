package app.zelo.limpeza.model;

/** Tipos de análise disponíveis. */
public enum ScanMode {
    LARGE("Arquivos grandes", "Arquivos com pelo menos 100 MB"),
    DUPLICATES("Arquivos duplicados", "Arquivos com conteúdo idêntico"),
    JUNK("Possível lixo", "Temporários, logs e arquivos de backup"),
    OLD("Arquivos antigos", "Sem alteração há pelo menos 180 dias");

    public final String title;
    public final String subtitle;

    ScanMode(String title, String subtitle) {
        this.title = title;
        this.subtitle = subtitle;
    }

    /** Verdadeiro quando os resultados podem aparecer aos poucos, durante a varredura. */
    public boolean streaming() {
        return this != DUPLICATES;
    }
}
