package app.zelo.limpeza.scan;

import app.zelo.limpeza.model.ScanFile;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;

/**
 * Percorre uma árvore de pastas em profundidade, sem recursão, para qualquer fonte que saiba listar
 * o conteúdo de uma pasta (SAF, java.io.File ou o serviço do Shizuku). Não depende do Android.
 */
public final class TreeWalker {
    /** Limite de segurança de memória. */
    public static final int MAX_FILES = 200_000;
    public static final int MAX_DEPTH = 32;

    public static final class Entry {
        public final String id;       // identificador usado para listar/abrir (caminho ou document id)
        public final String name;
        public final boolean directory;
        public final long size;
        public final long modified;
        public final String mime;     // pode ser null; então será deduzido pelo nome

        public Entry(String id, String name, boolean directory, long size, long modified, String mime) {
            this.id = id;
            this.name = name;
            this.directory = directory;
            this.size = size;
            this.modified = modified;
            this.mime = mime;
        }
    }

    public interface Lister {
        List<Entry> list(String dirId) throws IOException;
    }

    public static final class Summary {
        public final int scanned;
        public final boolean truncated;

        public Summary(int scanned, boolean truncated) {
            this.scanned = scanned;
            this.truncated = truncated;
        }
    }

    private static final class Dir {
        final String id;
        final String path;
        final int depth;

        Dir(String id, String path, int depth) {
            this.id = id;
            this.path = path;
            this.depth = depth;
        }
    }

    private TreeWalker() { }

    public static Summary walk(Lister lister, String rootId, BooleanSupplier cancelled, Consumer<ScanFile> onFile) {
        return walk(lister, rootId, cancelled, MimeTypes::guess, MAX_FILES, onFile);
    }

    public static Summary walk(Lister lister, String rootId, BooleanSupplier cancelled,
                               Function<String, String> mimeGuess, int maxFiles, Consumer<ScanFile> onFile) {
        Deque<Dir> pending = new ArrayDeque<>();
        pending.push(new Dir(rootId, "", 0));
        int scanned = 0;
        boolean truncated = false;

        while (!pending.isEmpty() && !cancelled.getAsBoolean()) {
            Dir dir = pending.pop();
            List<Entry> entries;
            try {
                entries = lister.list(dir.id);
            } catch (IOException | RuntimeException e) {
                continue; // pasta ilegível (permissão, provedor instável): ignora e segue
            }
            if (entries == null) continue;
            for (Entry e : entries) {
                if (cancelled.getAsBoolean()) break;
                String name = e.name == null ? "(sem nome)" : e.name;
                String rel = dir.path.isEmpty() ? name : dir.path + "/" + name;
                if (e.directory) {
                    if (dir.depth < MAX_DEPTH) pending.push(new Dir(e.id, rel, dir.depth + 1));
                    else truncated = true;
                } else {
                    if (scanned >= maxFiles) {
                        truncated = true;
                        pending.clear();
                        break;
                    }
                    scanned++;
                    String mime = e.mime != null ? e.mime : mimeGuess.apply(name);
                    onFile.accept(new ScanFile(e.id, name, rel, e.size, e.modified, mime));
                }
            }
        }
        return new Summary(scanned, truncated);
    }
}
