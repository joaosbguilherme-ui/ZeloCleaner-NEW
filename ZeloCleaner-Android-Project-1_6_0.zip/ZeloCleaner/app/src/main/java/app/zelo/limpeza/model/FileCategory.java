package app.zelo.limpeza.model;

import app.zelo.limpeza.scan.MimeTypes;

import java.util.Locale;

/** Categorias exibidas no resumo de espaço. */
public enum FileCategory {
    IMAGES("Imagens"),
    VIDEOS("Vídeos"),
    AUDIO("Áudio"),
    DOCUMENTS("Documentos"),
    ARCHIVES("Compactados"),
    APPS("Instaladores de apps"),
    OTHER("Outros");

    public final String label;

    FileCategory(String label) {
        this.label = label;
    }

    public static FileCategory of(String mime, String name) {
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        String ext = MimeTypes.extension(name);
        if (m.startsWith("image/")) return IMAGES;
        if (m.startsWith("video/")) return VIDEOS;
        if (m.startsWith("audio/")) return AUDIO;
        if (m.equals("application/vnd.android.package-archive") || ext.equals("apk") || ext.equals("xapk")
                || ext.equals("apks") || ext.equals("aab")) return APPS;
        switch (ext) {
            case "zip": case "rar": case "7z": case "tar": case "gz": case "tgz": case "bz2": case "xz":
                return ARCHIVES;
            case "pdf": case "doc": case "docx": case "xls": case "xlsx": case "ppt": case "pptx":
            case "odt": case "ods": case "odp": case "epub": case "rtf": case "txt": case "csv": case "md":
                return DOCUMENTS;
            default:
                break;
        }
        if (m.startsWith("text/") || m.equals("application/pdf") || m.contains("msword") || m.contains("officedocument")
                || m.contains("ms-excel") || m.contains("ms-powerpoint")) return DOCUMENTS;
        if (m.contains("zip") || m.contains("compressed") || m.contains("x-tar")) return ARCHIVES;
        return OTHER;
    }
}
