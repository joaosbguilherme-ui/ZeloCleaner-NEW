package app.zelo.limpeza.model;

import java.util.Comparator;
import java.util.Locale;

/** Critérios de ordenação da lista de resultados. */
public enum SortOrder {
    SIZE("Tamanho (maior primeiro)"),
    NAME("Nome (A–Z)"),
    OLDEST("Data (mais antigos primeiro)"),
    NEWEST("Data (mais recentes primeiro)");

    public final String label;

    SortOrder(String label) {
        this.label = label;
    }

    public Comparator<ScanFile> fileComparator() {
        switch (this) {
            case NAME:
                return (a, b) -> {
                    int c = a.name.toLowerCase(Locale.ROOT).compareTo(b.name.toLowerCase(Locale.ROOT));
                    return c != 0 ? c : a.relativePath.compareTo(b.relativePath);
                };
            case OLDEST:
                return (a, b) -> {
                    int c = Long.compare(dateKeyAsc(a), dateKeyAsc(b));
                    return c != 0 ? c : a.relativePath.compareTo(b.relativePath);
                };
            case NEWEST:
                return (a, b) -> {
                    int c = Long.compare(dateKeyDesc(a), dateKeyDesc(b));
                    return c != 0 ? c : a.relativePath.compareTo(b.relativePath);
                };
            case SIZE:
            default:
                return (a, b) -> {
                    int c = Long.compare(b.size, a.size);
                    return c != 0 ? c : a.relativePath.compareTo(b.relativePath);
                };
        }
    }

    /** Ordena grupos de duplicados pelo mesmo critério (usando o arquivo original ou o espaço recuperável). */
    public Comparator<DuplicateGroup> groupComparator() {
        if (this == SIZE) {
            return (a, b) -> {
                int c = Long.compare(b.wastedBytes(), a.wastedBytes());
                return c != 0 ? c : a.original.relativePath.compareTo(b.original.relativePath);
            };
        }
        Comparator<ScanFile> files = fileComparator();
        return (a, b) -> files.compare(a.original, b.original);
    }

    // Datas desconhecidas (0) vão sempre para o fim da lista.
    private static long dateKeyAsc(ScanFile f) {
        return f.modified > 0 ? f.modified : Long.MAX_VALUE;
    }

    private static long dateKeyDesc(ScanFile f) {
        return f.modified > 0 ? -f.modified : Long.MAX_VALUE;
    }
}
