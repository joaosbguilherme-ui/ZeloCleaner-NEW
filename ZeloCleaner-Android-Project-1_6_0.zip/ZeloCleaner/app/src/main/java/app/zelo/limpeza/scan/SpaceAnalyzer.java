package app.zelo.limpeza.scan;

import app.zelo.limpeza.model.FileCategory;
import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.model.SpaceSummary;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Acumula tamanhos por categoria e por pasta (até uma profundidade) enquanto os arquivos chegam. */
public final class SpaceAnalyzer {
    private final int maxFolderDepth;
    private final SpaceSummary.Total[] byCategory = new SpaceSummary.Total[FileCategory.values().length];
    private final Map<String, long[]> folders = new HashMap<>(); // [bytes, count]
    private long totalBytes;
    private int totalFiles;

    public SpaceAnalyzer(int maxFolderDepth) {
        this.maxFolderDepth = maxFolderDepth;
        for (int i = 0; i < byCategory.length; i++) byCategory[i] = new SpaceSummary.Total();
    }

    public void add(ScanFile f) {
        totalBytes += f.size;
        totalFiles++;
        SpaceSummary.Total t = byCategory[FileCategory.of(f.mimeType, f.name).ordinal()];
        t.bytes += f.size;
        t.count++;

        String path = f.relativePath;
        int depth = 0;
        int slash = path.indexOf('/');
        while (slash >= 0 && depth < maxFolderDepth) {
            depth++;
            long[] acc = folders.computeIfAbsent(path.substring(0, slash), k -> new long[2]);
            acc[0] += f.size;
            acc[1]++;
            slash = path.indexOf('/', slash + 1);
        }
    }

    public SpaceSummary result(int maxFolders) {
        SpaceSummary s = new SpaceSummary(totalBytes, totalFiles);
        for (FileCategory c : FileCategory.values()) {
            SpaceSummary.Total src = byCategory[c.ordinal()];
            SpaceSummary.Total dst = s.categories.get(c);
            dst.bytes = src.bytes;
            dst.count = src.count;
        }
        List<SpaceSummary.FolderTotal> all = new ArrayList<>();
        for (Map.Entry<String, long[]> e : folders.entrySet()) {
            all.add(new SpaceSummary.FolderTotal(e.getKey(), e.getValue()[0], (int) e.getValue()[1]));
        }
        Collections.sort(all, (a, b) -> {
            int c = Long.compare(b.bytes, a.bytes);
            return c != 0 ? c : a.path.compareTo(b.path);
        });
        s.folders.addAll(all.subList(0, Math.min(maxFolders, all.size())));
        return s;
    }
}
