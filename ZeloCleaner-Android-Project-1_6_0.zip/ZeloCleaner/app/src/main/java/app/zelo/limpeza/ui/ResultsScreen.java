package app.zelo.limpeza.ui;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import app.zelo.limpeza.R;
import app.zelo.limpeza.model.DuplicateGroup;
import app.zelo.limpeza.model.FileCategory;
import app.zelo.limpeza.model.ResultRow;
import app.zelo.limpeza.model.RowBuilder;
import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.model.ScanMode;
import app.zelo.limpeza.model.SortOrder;
import app.zelo.limpeza.source.FileSource;
import app.zelo.limpeza.util.Formatters;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import static app.zelo.limpeza.ui.UiKit.*;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.progressindicator.LinearProgressIndicator;

/**
 * Tela de resultados: lista com reciclagem de views (ListView), ordenação, agrupamento de duplicados,
 * miniaturas, abertura do arquivo e atualização em lotes enquanto a análise ainda roda.
 */
public final class ResultsScreen {
    public interface Host {
        void onBack();
        void onStopScan();
        void onDelete(List<ScanFile> selected);
        void onShare(ScanMode mode, int scanned, List<ScanFile> files);
        void onOpen(ScanFile file);
    }

    private static final int TYPE_HEADER = 0;
    private static final int TYPE_FILE = 1;

    private final Activity activity;
    private final UiKit ui;
    private final Host host;
    private final ScanMode mode;
    private final String folderName;
    private final ThumbnailLoader thumbnails;
    private final DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.SHORT);

    private final List<ScanFile> files = new ArrayList<>();
    private final List<DuplicateGroup> groups = new ArrayList<>();
    private List<ResultRow> rows = new ArrayList<>();
    private SortOrder sortOrder = SortOrder.SIZE;
    private int scanned;
    private boolean running;
    private boolean truncated;

    private final LinearLayout root;
    private final ListView list;
    private final Adapter adapter = new Adapter();
    private TextView countView;
    private TextView statsView;
    private TextView sizeView;
    private TextView bannerView;
    private MaterialButton stopButton;
    private MaterialButton sortButton;
    private MaterialCheckBox selectAll;
    private TextView selectedSummary;
    private MaterialButton deleteButton;
    private MaterialButton shareButton;
    private LinearLayout emptyView;
    private TextView emptyText;
    private LinearProgressIndicator progressBar;

    public ResultsScreen(Activity activity, UiKit ui, Host host, ScanMode mode, FileSource source, String folderName) {
        this.activity = activity;
        this.ui = ui;
        this.host = host;
        this.mode = mode;
        this.folderName = folderName;
        this.thumbnails = new ThumbnailLoader(source, ui.dp(96));

        root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(-1, -2);
        barLp.setMargins(ui.dp(16), ui.dp(10), ui.dp(16), ui.dp(2));
        root.addView(ui.topBar(mode.title, host::onBack), barLp);

        list = new ListView(activity);
        list.setDivider(null);
        list.setBackgroundColor(BG);
        list.setCacheColorHint(BG);
        list.setSelector(android.R.color.transparent);
        list.setClipToPadding(false);
        list.addHeaderView(buildHeader(), null, false);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            int index = position - list.getHeaderViewsCount();
            if (index < 0 || index >= rows.size()) return;
            ResultRow row = rows.get(index);
            if (!row.isHeader()) host.onOpen(row.file);
        });
        list.setOnItemLongClickListener((parent, view, position, id) -> {
            int index = position - list.getHeaderViewsCount();
            if (index < 0 || index >= rows.size()) return true;
            ResultRow row = rows.get(index);
            if (row.isHeader()) return true;
            row.file.selected = !row.file.selected;
            adapter.notifyDataSetChanged();
            refreshSelection();
            return true;
        });
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(buildActionBar(), new LinearLayout.LayoutParams(-1, -2));
    }

    public View root() {
        return root;
    }

    public void shutdown() {
        thumbnails.shutdown();
    }

    // ---------- estado ----------

    public void begin() {
        running = true;
        refreshAll();
    }

    public void setProgress(int scannedNow) {
        scanned = scannedNow;
        refreshHeader();
    }

    public void addBatch(List<ScanFile> batch) {
        files.addAll(batch);
        rebuildRows();
    }

    public void finish(int scannedTotal, boolean wasTruncated, List<DuplicateGroup> found) {
        scanned = scannedTotal;
        truncated = wasTruncated;
        running = false;
        if (found != null) {
            groups.clear();
            groups.addAll(found);
            files.clear();
            for (DuplicateGroup g : found) files.addAll(g.copies);
        }
        rebuildRows();
    }

    /** O usuário parou a análise: mantém o que já chegou e marca como parcial. */
    public void markStopped() {
        running = false;
        truncated = true;
        refreshAll();
    }

    public boolean isRunning() {
        return running;
    }

    public void removeDeleted(List<ScanFile> deleted) {
        Set<ScanFile> gone = new HashSet<>(deleted);
        files.removeAll(gone);
        for (DuplicateGroup g : groups) g.copies.removeAll(gone);
        groups.removeIf(g -> g.copies.isEmpty());
        rebuildRows();
    }

    public List<ScanFile> files() {
        return files;
    }

    public int scanned() {
        return scanned;
    }

    private List<ScanFile> selectedFiles() {
        List<ScanFile> selected = new ArrayList<>();
        for (ScanFile f : files) if (f.selected) selected.add(f);
        return selected;
    }

    // ---------- construção da interface ----------

    private View buildHeader() {
        LinearLayout h = new LinearLayout(activity);
        h.setOrientation(LinearLayout.VERTICAL);
        h.setPadding(ui.dp(20), ui.dp(8), ui.dp(20), ui.dp(8));

        h.addView(ui.text(mode.subtitle, 13, MUTED, false));
        LinearLayout where = new LinearLayout(activity);
        where.setOrientation(LinearLayout.HORIZONTAL);
        where.setGravity(Gravity.CENTER_VERTICAL);
        where.addView(ui.icon(R.drawable.ic_folder, MUTED), new LinearLayout.LayoutParams(ui.dp(14), ui.dp(14)));
        TextView whereText = ui.text(folderName, 12, MUTED, false);
        whereText.setMaxLines(1);
        LinearLayout.LayoutParams whereTextLp = new LinearLayout.LayoutParams(0, -2, 1f);
        whereTextLp.leftMargin = ui.dp(6);
        where.addView(whereText, whereTextLp);
        h.addView(where, topMargin(4));

        LinearLayout summary = new LinearLayout(activity);
        summary.setOrientation(LinearLayout.VERTICAL);
        summary.setPadding(ui.dp(18), ui.dp(16), ui.dp(18), ui.dp(16));
        summary.setBackground(ui.surfaceDrawable(ACCENT_CONTAINER, 24));
        sizeView = ui.text("", 30, ON_ACCENT_CONTAINER, true);
        sizeView.setLetterSpacing(-0.02f);
        summary.addView(sizeView);
        countView = ui.text("", 14, ON_ACCENT_CONTAINER, true);
        summary.addView(countView, topMargin(2));
        statsView = ui.text("", 12, ON_ACCENT_CONTAINER, false);
        summary.addView(statsView, topMargin(4));
        progressBar = new LinearProgressIndicator(activity);
        progressBar.setIndeterminate(true);
        progressBar.setIndicatorColor(ACCENT);
        progressBar.setTrackColor(withAlphaColor(ON_ACCENT_CONTAINER, 0x26));
        progressBar.setTrackThickness(ui.dp(6));
        progressBar.setTrackCornerRadius(ui.dp(3));
        summary.addView(progressBar, topMargin(12));
        LinearLayout.LayoutParams sumLp = new LinearLayout.LayoutParams(-1, -2);
        sumLp.topMargin = ui.dp(12);
        sumLp.bottomMargin = ui.dp(10);
        h.addView(summary, sumLp);

        bannerView = ui.text("", 13, ACCENT, true);
        h.addView(bannerView, topMargin(2));
        stopButton = ui.button("Parar e manter resultados parciais", CARD_ALT, TEXT, R.drawable.ic_stop, false);
        stopButton.setOnClickListener(v -> host.onStopScan());
        LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(-1, ui.dp(48));
        stopLp.topMargin = ui.dp(6);
        stopLp.bottomMargin = ui.dp(8);
        h.addView(stopButton, stopLp);

        LinearLayout caution = new LinearLayout(activity);
        caution.setOrientation(LinearLayout.HORIZONTAL);
        caution.setGravity(Gravity.CENTER_VERTICAL);
        caution.setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12));
        caution.setBackground(ui.rounded(WARNING_CONTAINER, 16));
        caution.addView(ui.icon(R.drawable.ic_warning, ON_WARNING_CONTAINER), new LinearLayout.LayoutParams(ui.dp(20), ui.dp(20)));
        TextView cautionText = ui.text("Revise antes de excluir. Toque em um arquivo para abri-lo; pressione e segure para marcá-lo.", 12, ON_WARNING_CONTAINER, false);
        LinearLayout.LayoutParams cautionLp = new LinearLayout.LayoutParams(0, -2, 1f);
        cautionLp.leftMargin = ui.dp(12);
        caution.addView(cautionText, cautionLp);
        h.addView(caution, topMargin(4));

        sortButton = ui.button("", CARD_ALT, TEXT, R.drawable.ic_sort, false);
        sortButton.setOnClickListener(v -> chooseSort());
        h.addView(sortButton, topMargin(10, ui.dp(48)));

        selectAll = new MaterialCheckBox(activity);
        selectAll.setUseMaterialThemeColors(false);
        selectAll.setText("Selecionar todos os resultados");
        selectAll.setTextColor(TEXT);
        selectAll.setButtonTintList(ColorStateList.valueOf(ACCENT));
        selectAll.setOnClickListener(v -> {
            boolean checked = selectAll.isChecked();
            for (ScanFile f : files) f.selected = checked;
            adapter.notifyDataSetChanged();
            refreshSelection();
        });
        h.addView(selectAll, topMargin(6));

        emptyView = new LinearLayout(activity);
        emptyView.setOrientation(LinearLayout.VERTICAL);
        emptyView.setGravity(Gravity.CENTER_HORIZONTAL);
        emptyView.setPadding(0, ui.dp(28), 0, ui.dp(28));
        emptyView.addView(ui.badge(R.drawable.ic_search_off, MUTED, CARD_ALT, 32, 28), new LinearLayout.LayoutParams(ui.dp(64), ui.dp(64)));
        emptyText = ui.text("Nada encontrado ainda.", 14, MUTED, false);
        emptyText.setGravity(Gravity.CENTER);
        emptyView.addView(emptyText, topMargin(14));
        h.addView(emptyView);
        return h;
    }

    private View buildActionBar() {
        LinearLayout bar = new LinearLayout(activity);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackground(ui.topSheetDrawable(SURFACE, 24));
        bar.setPadding(ui.dp(20), ui.dp(14), ui.dp(20), ui.dp(16));
        selectedSummary = ui.text("Nenhum arquivo selecionado", 13, MUTED, true);
        bar.addView(selectedSummary);
        LinearLayout buttons = new LinearLayout(activity);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        deleteButton = ui.button("Excluir", DANGER_CONTAINER, ON_DANGER_CONTAINER, R.drawable.ic_delete, false);
        deleteButton.setOnClickListener(v -> confirmDelete());
        LinearLayout.LayoutParams delLp = new LinearLayout.LayoutParams(0, ui.dp(48), 1.3f);
        buttons.addView(deleteButton, delLp);
        shareButton = ui.button("Compartilhar", CARD_ALT, TEXT, R.drawable.ic_share, false);
        shareButton.setOnClickListener(v -> host.onShare(mode, scanned, new ArrayList<>(files)));
        LinearLayout.LayoutParams shLp = new LinearLayout.LayoutParams(0, ui.dp(48), 1f);
        shLp.leftMargin = ui.dp(8);
        buttons.addView(shareButton, shLp);
        LinearLayout.LayoutParams bLp = new LinearLayout.LayoutParams(-1, -2);
        bLp.topMargin = ui.dp(8);
        bar.addView(buttons, bLp);
        return bar;
    }

    private LinearLayout.LayoutParams topMargin(int dpValue) {
        return topMargin(dpValue, -2);
    }

    private LinearLayout.LayoutParams topMargin(int dpValue, int height) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, height);
        lp.topMargin = ui.dp(dpValue);
        return lp;
    }

    // ---------- atualização ----------

    private void chooseSort() {
        SortOrder[] orders = SortOrder.values();
        String[] labels = new String[orders.length];
        int checked = 0;
        for (int i = 0; i < orders.length; i++) {
            labels[i] = orders[i].label;
            if (orders[i] == sortOrder) checked = i;
        }
        new MaterialAlertDialogBuilder(activity)
                .setTitle("Ordenar por")
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    sortOrder = orders[which];
                    dialog.dismiss();
                    rebuildRows();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void rebuildRows() {
        rows = RowBuilder.build(mode, files, groups, sortOrder);
        adapter.notifyDataSetChanged();
        refreshAll();
    }

    private void refreshAll() {
        refreshHeader();
        refreshSelection();
    }

    private void refreshHeader() {
        long total = 0;
        for (ScanFile f : files) total += f.size;
        sizeView.setText(Formatters.formatBytes(total, Locale.getDefault()));
        countView.setText(files.size() + " arquivo(s) encontrado(s)"
                + (mode == ScanMode.DUPLICATES ? " · espaço ocupado pelas cópias" : ""));
        statsView.setText("Arquivos examinados: " + scanned
                + (truncated && !running ? " (análise parcial ou limite de segurança atingido)" : ""));
        progressBar.setVisibility(running ? View.VISIBLE : View.GONE);
        bannerView.setVisibility(running ? View.VISIBLE : View.GONE);
        bannerView.setText("Analisando… " + scanned + " arquivos examinados");
        stopButton.setVisibility(running && mode.streaming() ? View.VISIBLE : View.GONE);
        sortButton.setText("Ordenar: " + sortOrder.label);
        emptyView.setVisibility(files.isEmpty() ? View.VISIBLE : View.GONE);
        emptyText.setText(running ? "Procurando…" : "Nada encontrado nesta pasta. Tente outra pasta ou outra análise.");
        selectAll.setVisibility(files.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void refreshSelection() {
        int count = 0;
        long bytes = 0;
        boolean all = !files.isEmpty();
        for (ScanFile f : files) {
            if (f.selected) { count++; bytes += f.size; } else all = false;
        }
        selectAll.setChecked(all);
        selectedSummary.setText(count == 0 ? "Nenhum arquivo selecionado"
                : count + " selecionado(s) · " + Formatters.formatBytes(bytes, Locale.getDefault()));
        deleteButton.setText(count > 0 ? "Excluir (" + count + ")" : "Excluir");
        deleteButton.setEnabled(count > 0 && !running);
        deleteButton.setAlpha(count > 0 && !running ? 1f : 0.45f);
        shareButton.setEnabled(!files.isEmpty());
        shareButton.setAlpha(files.isEmpty() ? 0.45f : 1f);
    }

    private void confirmDelete() {
        List<ScanFile> selected = selectedFiles();
        if (selected.isEmpty()) return;
        long bytes = 0;
        for (ScanFile f : selected) bytes += f.size;
        new MaterialAlertDialogBuilder(activity)
                .setTitle("Excluir arquivos selecionados?")
                .setMessage("Você selecionou " + selected.size() + " arquivo(s) ("
                        + Formatters.formatBytes(bytes, Locale.getDefault())
                        + "). A exclusão pode ser permanente e não usa uma lixeira do Zelo. Revise os nomes antes de continuar.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Excluir", (d, w) -> host.onDelete(selected))
                .show();
    }

    // ---------- adapter ----------

    private static final class FileHolder {
        LinearLayout card;
        int bgState; // 0 = sem fundo definido, 1 = normal, 2 = selecionado
        MaterialCheckBox check;
        FrameLayout iconBox;
        ImageView glyph;
        ImageView thumb;
        TextView name;
        TextView meta;
        TextView reason;
        TextView path;
    }

    private void toggleGroup(DuplicateGroup g) {
        boolean allSelected = true;
        for (ScanFile f : g.copies) if (!f.selected) { allSelected = false; break; }
        for (ScanFile f : g.copies) f.selected = !allSelected;
        adapter.notifyDataSetChanged();
        refreshSelection();
    }

    private final class Adapter extends BaseAdapter {
        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int position) { return rows.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int position) { return rows.get(position).isHeader() ? TYPE_HEADER : TYPE_FILE; }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ResultRow row = rows.get(position);
            return row.isHeader() ? headerView(row.group, convertView) : fileView(row.file, convertView);
        }

        private View headerView(DuplicateGroup g, View convertView) {
            LinearLayout wrap;
            TextView title;
            TextView sub;
            TextView action;
            if (convertView == null) {
                wrap = new LinearLayout(activity);
                wrap.setOrientation(LinearLayout.HORIZONTAL);
                wrap.setGravity(Gravity.CENTER_VERTICAL);
                wrap.setPadding(ui.dp(18), ui.dp(16), ui.dp(18), ui.dp(4));
                wrap.addView(ui.badge(R.drawable.ic_copy, ACCENT, ACCENT_CONTAINER, 18, 10),
                        new LinearLayout.LayoutParams(ui.dp(34), ui.dp(34)));
                LinearLayout col = new LinearLayout(activity);
                col.setOrientation(LinearLayout.VERTICAL);
                title = ui.text("", 13, ACCENT, true);
                sub = ui.text("", 11, MUTED, false);
                sub.setMaxLines(2);
                col.addView(title);
                col.addView(sub);
                LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(0, -2, 1f);
                colLp.leftMargin = ui.dp(10);
                colLp.rightMargin = ui.dp(8);
                wrap.addView(col, colLp);
                action = ui.chip("Marcar cópias", ACCENT_CONTAINER, ON_ACCENT_CONTAINER);
                action.setClickable(true);
                action.setFocusable(true);
                action.setOnClickListener(v -> {
                    Object tag = v.getTag();
                    if (tag instanceof DuplicateGroup) toggleGroup((DuplicateGroup) tag);
                });
                wrap.addView(action, new LinearLayout.LayoutParams(-2, -2));
                wrap.setTag(new TextView[]{title, sub, action});
            } else {
                wrap = (LinearLayout) convertView;
                TextView[] tv = (TextView[]) wrap.getTag();
                title = tv[0];
                sub = tv[1];
                action = tv[2];
            }
            title.setText(g.copies.size() + " cópia(s) · "
                    + Formatters.formatBytes(g.wastedBytes(), Locale.getDefault()) + " recuperáveis");
            sub.setText("Original (mantido): " + g.original.relativePath);
            action.setTag(g);
            return wrap;
        }

        private View fileView(ScanFile f, View convertView) {
            FileHolder h;
            View outer;
            if (convertView == null) {
                FrameLayout frame = new FrameLayout(activity);
                frame.setPadding(ui.dp(18), ui.dp(4), ui.dp(18), ui.dp(4));
                LinearLayout card = new LinearLayout(activity);
                card.setOrientation(LinearLayout.HORIZONTAL);
                card.setGravity(Gravity.CENTER_VERTICAL);
                card.setPadding(ui.dp(6), ui.dp(10), ui.dp(12), ui.dp(10));
                frame.addView(card, new FrameLayout.LayoutParams(-1, -2));

                final FileHolder holder = new FileHolder();
                h = holder;
                h.card = card;
                h.check = new MaterialCheckBox(activity);
                h.check.setUseMaterialThemeColors(false);
                h.check.setButtonTintList(ColorStateList.valueOf(ACCENT));
                h.check.setFocusable(false);
                card.addView(h.check, new LinearLayout.LayoutParams(-2, -2));

                h.iconBox = new FrameLayout(activity);
                h.glyph = new ImageView(activity);
                h.glyph.setScaleType(ImageView.ScaleType.FIT_CENTER);
                h.iconBox.addView(h.glyph, new FrameLayout.LayoutParams(ui.dp(24), ui.dp(24), Gravity.CENTER));
                h.thumb = new ImageView(activity);
                h.thumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
                h.iconBox.addView(h.thumb, new FrameLayout.LayoutParams(-1, -1));
                h.iconBox.setClipToOutline(true);
                LinearLayout.LayoutParams tbLp = new LinearLayout.LayoutParams(ui.dp(52), ui.dp(52));
                tbLp.rightMargin = ui.dp(12);
                card.addView(h.iconBox, tbLp);

                LinearLayout col = new LinearLayout(activity);
                col.setOrientation(LinearLayout.VERTICAL);
                h.name = ui.text("", 14, TEXT, true);
                h.name.setMaxLines(2);
                h.meta = ui.text("", 12, ACCENT, true);
                h.meta.setMaxLines(1);
                h.reason = ui.chip("", CARD_ALT, MUTED);
                h.reason.setTextSize(10);
                h.reason.setPadding(ui.dp(8), ui.dp(2), ui.dp(8), ui.dp(2));
                h.reason.setMaxLines(1);
                h.path = ui.text("", 11, MUTED, false);
                h.path.setMaxLines(2);
                col.addView(h.name);
                col.addView(h.meta, topMargin(2));
                LinearLayout.LayoutParams reasonLp = new LinearLayout.LayoutParams(-2, -2);
                reasonLp.topMargin = ui.dp(4);
                col.addView(h.reason, reasonLp);
                col.addView(h.path, topMargin(4));
                card.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));

                h.check.setOnClickListener(v -> {
                    ScanFile target = (ScanFile) v.getTag();
                    if (target == null) return;
                    target.selected = ((MaterialCheckBox) v).isChecked();
                    applyCardBackground(holder, target.selected);
                    refreshSelection();
                });
                frame.setTag(h);
                outer = frame;
            } else {
                outer = convertView;
                h = (FileHolder) outer.getTag();
            }
            h.check.setTag(f);
            h.check.setChecked(f.selected);
            applyCardBackground(h, f.selected);
            h.name.setText(f.name);
            String date = f.modified > 0 ? "  ·  " + dateFormat.format(new Date(f.modified)) : "";
            h.meta.setText(Formatters.formatBytes(f.size, Locale.getDefault()) + date);
            if (f.reason == null || f.reason.isEmpty()) {
                h.reason.setVisibility(View.GONE);
            } else {
                h.reason.setVisibility(View.VISIBLE);
                h.reason.setText(f.reason);
            }
            h.path.setText(f.relativePath);

            FileCategory category = FileCategory.of(f.mimeType, f.name);
            int color = categoryColor(category);
            h.iconBox.setBackground(ui.rounded(withAlphaColor(color, 0x2E), 14));
            h.glyph.setImageResource(categoryIcon(category));
            h.glyph.setImageTintList(ColorStateList.valueOf(color));
            if (f.isMedia()) thumbnails.load(f, h.thumb);
            else { h.thumb.setTag(null); h.thumb.setImageDrawable(null); }
            return outer;
        }

        private void applyCardBackground(FileHolder h, boolean selected) {
            int state = selected ? 2 : 1;
            if (h.bgState == state) return;
            h.bgState = state;
            h.card.setBackground(ui.rippleSurface(selected ? ACCENT_CONTAINER : CARD, 18));
        }
    }
}
