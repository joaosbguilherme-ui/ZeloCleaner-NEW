package app.zelo.limpeza.ui;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import app.zelo.limpeza.R;
import app.zelo.limpeza.model.FileCategory;
import app.zelo.limpeza.model.SpaceSummary;
import app.zelo.limpeza.scan.AppSpaceRanker;
import app.zelo.limpeza.util.Formatters;

import java.util.List;
import java.util.Locale;

import static app.zelo.limpeza.ui.UiKit.*;

/** Blocos de interface do resumo de espaço e do ranking de apps. */
public final class SummaryViews {
    private SummaryViews() { }

    private static LinearLayout.LayoutParams lp(UiKit ui, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = ui.dp(topDp);
        return p;
    }

    /** Barra horizontal proporcional (0..1). */
    private static View bar(Context ctx, UiKit ui, double fraction, int color) {
        LinearLayout track = new LinearLayout(ctx);
        track.setOrientation(LinearLayout.HORIZONTAL);
        track.setBackground(ui.rounded(CARD_ALT, 4));
        View fill = new View(ctx);
        fill.setBackground(ui.rounded(color, 4));
        float f = (float) Math.max(0.02, Math.min(1.0, fraction));
        track.addView(fill, new LinearLayout.LayoutParams(0, ui.dp(8), f));
        track.addView(new View(ctx), new LinearLayout.LayoutParams(0, ui.dp(8), 1f - f));
        return track;
    }

    private static TextView sectionTitle(UiKit ui, String label) {
        return ui.text(label, 15, TEXT, true);
    }

    private static LinearLayout compactCard(UiKit ui) {
        LinearLayout row = ui.card();
        row.setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12));
        return row;
    }

    public static void addSpace(LinearLayout content, UiKit ui, Context ctx, SpaceSummary s, int scanned, boolean truncated) {
        Locale l = Locale.getDefault();

        // Cartão principal em tom primário.
        LinearLayout hero = new LinearLayout(ctx);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(ui.dp(20), ui.dp(20), ui.dp(20), ui.dp(20));
        hero.setBackground(ui.surfaceDrawable(ACCENT_CONTAINER, 26));
        hero.addView(ui.text("TOTAL ANALISADO", 10, ON_ACCENT_CONTAINER, true));
        TextView total = ui.text(Formatters.formatBytes(s.totalBytes, l), 34, ON_ACCENT_CONTAINER, true);
        total.setLetterSpacing(-0.02f);
        hero.addView(total, lp(ui, 6));
        hero.addView(ui.text(s.totalFiles + " arquivos" + (truncated ? " · limite de segurança atingido" : ""), 12, ON_ACCENT_CONTAINER, false), lp(ui, 2));

        // Barra empilhada por categoria, com pequenos espaços entre os trechos.
        LinearLayout stacked = new LinearLayout(ctx);
        stacked.setOrientation(LinearLayout.HORIZONTAL);
        stacked.setBackground(ui.rounded(withAlphaColor(ON_ACCENT_CONTAINER, 0x26), 8));
        FileCategory[] cats = FileCategory.values();
        boolean first = true;
        for (FileCategory c : cats) {
            long bytes = s.categories.get(c).bytes;
            if (s.totalBytes <= 0 || bytes <= 0) continue;
            View seg = new View(ctx);
            seg.setBackground(ui.rounded(categoryColor(c), 4));
            LinearLayout.LayoutParams segLp = new LinearLayout.LayoutParams(0, ui.dp(14), (float) bytes);
            if (!first) segLp.leftMargin = ui.dp(2);
            first = false;
            stacked.addView(seg, segLp);
        }
        hero.addView(stacked, lp(ui, 16));
        content.addView(hero, lp(ui, 16));

        content.addView(sectionTitle(ui, "Por categoria"), lp(ui, 22));
        for (FileCategory c : cats) {
            SpaceSummary.Total t = s.categories.get(c);
            int color = categoryColor(c);
            LinearLayout row = compactCard(ui);
            LinearLayout head = new LinearLayout(ctx);
            head.setOrientation(LinearLayout.HORIZONTAL);
            head.setGravity(Gravity.CENTER_VERTICAL);
            head.addView(ui.badge(categoryIcon(c), color, withAlphaColor(color, 0x2E), 20, 12),
                    new LinearLayout.LayoutParams(ui.dp(38), ui.dp(38)));
            LinearLayout names = new LinearLayout(ctx);
            names.setOrientation(LinearLayout.VERTICAL);
            names.addView(ui.text(c.label, 14, TEXT, true));
            names.addView(ui.text(t.count + " arquivo(s)", 11, MUTED, false), lp(ui, 1));
            LinearLayout.LayoutParams namesLp = new LinearLayout.LayoutParams(0, -2, 1f);
            namesLp.leftMargin = ui.dp(12);
            head.addView(names, namesLp);
            head.addView(ui.text(Formatters.formatBytes(t.bytes, l), 14, TEXT, true));
            row.addView(head);
            double fraction = s.totalBytes > 0 ? (double) t.bytes / s.totalBytes : 0;
            row.addView(bar(ctx, ui, fraction, color), lp(ui, 10));
            content.addView(row, lp(ui, 8));
        }

        if (!s.folders.isEmpty()) {
            content.addView(sectionTitle(ui, "Pastas que mais ocupam"), lp(ui, 22));
            long max = s.folders.get(0).bytes;
            for (SpaceSummary.FolderTotal f : s.folders) {
                LinearLayout row = compactCard(ui);
                LinearLayout head = new LinearLayout(ctx);
                head.setOrientation(LinearLayout.HORIZONTAL);
                head.setGravity(Gravity.CENTER_VERTICAL);
                head.addView(ui.badge(R.drawable.ic_folder, ACCENT, ACCENT_CONTAINER, 20, 12),
                        new LinearLayout.LayoutParams(ui.dp(38), ui.dp(38)));
                LinearLayout names = new LinearLayout(ctx);
                names.setOrientation(LinearLayout.VERTICAL);
                TextView path = ui.text(f.path, 13, TEXT, true);
                path.setMaxLines(2);
                names.addView(path);
                names.addView(ui.text(f.count + " arquivo(s)", 11, MUTED, false), lp(ui, 1));
                LinearLayout.LayoutParams namesLp = new LinearLayout.LayoutParams(0, -2, 1f);
                namesLp.leftMargin = ui.dp(12);
                namesLp.rightMargin = ui.dp(8);
                head.addView(names, namesLp);
                head.addView(ui.text(Formatters.formatBytes(f.bytes, l), 13, ACCENT, true));
                row.addView(head);
                row.addView(bar(ctx, ui, max > 0 ? (double) f.bytes / max : 0, ACCENT), lp(ui, 10));
                content.addView(row, lp(ui, 8));
            }
        }
    }

    public static void addApps(LinearLayout content, UiKit ui, Context ctx, List<AppSpaceRanker.AppSpace> apps) {
        Locale l = Locale.getDefault();
        PackageManager pm = ctx.getPackageManager();

        LinearLayout note = new LinearLayout(ctx);
        note.setOrientation(LinearLayout.HORIZONTAL);
        note.setGravity(Gravity.CENTER_VERTICAL);
        note.setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12));
        note.setBackground(ui.rounded(WARNING_CONTAINER, 16));
        note.addView(ui.icon(R.drawable.ic_info, ON_WARNING_CONTAINER), new LinearLayout.LayoutParams(ui.dp(20), ui.dp(20)));
        TextView noteText = ui.text("Tamanho das pastas Android/data e Android/obb de cada app. Os nomes só aparecem para apps visíveis ao Zelo; os demais mostram o nome do pacote. O app em si (código) não está incluído.", 12, ON_WARNING_CONTAINER, false);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(0, -2, 1f);
        noteLp.leftMargin = ui.dp(12);
        note.addView(noteText, noteLp);
        content.addView(note, lp(ui, 14));

        if (apps.isEmpty()) {
            content.addView(ui.text("Nenhuma pasta de app encontrada.", 15, MUTED, false), lp(ui, 16));
            return;
        }
        long max = apps.get(0).total();
        for (AppSpaceRanker.AppSpace app : apps) {
            String label = null;
            Drawable appIcon = null;
            try {
                ApplicationInfo info = pm.getApplicationInfo(app.packageName, 0);
                label = String.valueOf(pm.getApplicationLabel(info));
                appIcon = pm.getApplicationIcon(info);
            } catch (PackageManager.NameNotFoundException ignored) {
                // Sem permissão de visibilidade ou não instalado: mostra o pacote.
            }
            LinearLayout row = compactCard(ui);
            LinearLayout head = new LinearLayout(ctx);
            head.setOrientation(LinearLayout.HORIZONTAL);
            head.setGravity(Gravity.CENTER_VERTICAL);
            if (appIcon != null) {
                ImageView iv = new ImageView(ctx);
                iv.setImageDrawable(appIcon);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                head.addView(iv, new LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)));
            } else {
                head.addView(ui.badge(R.drawable.ic_apps, MUTED, CARD_ALT, 22, 12),
                        new LinearLayout.LayoutParams(ui.dp(40), ui.dp(40)));
            }
            LinearLayout names = new LinearLayout(ctx);
            names.setOrientation(LinearLayout.VERTICAL);
            TextView name = ui.text(label != null ? label : app.packageName, 14, TEXT, true);
            name.setMaxLines(2);
            names.addView(name);
            String detail = (label != null ? app.packageName + "\n" : "")
                    + "data: " + Formatters.formatBytes(app.dataBytes, l) + "  ·  obb: " + Formatters.formatBytes(app.obbBytes, l);
            names.addView(ui.text(detail, 11, MUTED, false), lp(ui, 1));
            LinearLayout.LayoutParams namesLp = new LinearLayout.LayoutParams(0, -2, 1f);
            namesLp.leftMargin = ui.dp(12);
            namesLp.rightMargin = ui.dp(8);
            head.addView(names, namesLp);
            head.addView(ui.text(Formatters.formatBytes(app.total(), l), 14, ACCENT, true));
            row.addView(head);
            row.addView(bar(ctx, ui, max > 0 ? (double) app.total() / max : 0, ACCENT), lp(ui, 10));
            content.addView(row, lp(ui, 8));
        }
    }
}
