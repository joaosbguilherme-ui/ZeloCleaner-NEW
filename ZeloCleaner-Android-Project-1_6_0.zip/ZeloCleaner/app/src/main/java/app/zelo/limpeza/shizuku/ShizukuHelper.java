package app.zelo.limpeza.shizuku;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.IBinder;
import android.widget.Toast;

import java.util.function.Consumer;

import rikka.shizuku.Shizuku;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

/**
 * Detecta o Shizuku, pede a permissão e conecta ao {@link FileService}.
 * Tudo é opcional: se o Shizuku não estiver disponível, o restante do app continua funcionando.
 */
public final class ShizukuHelper {
    public static final String SHIZUKU_PACKAGE = "moe.shizuku.privileged.api";
    private static final int REQUEST_CODE = 9117;

    public enum State { NOT_INSTALLED, NOT_RUNNING, OUTDATED, NEEDS_PERMISSION, READY }

    private Activity activity;
    private IFileService service;
    private Consumer<IFileService> pending;
    private Shizuku.UserServiceArgs args;

    private final Shizuku.OnRequestPermissionResultListener permissionListener = (code, result) -> {
        if (code != REQUEST_CODE) return;
        if (result == PackageManager.PERMISSION_GRANTED && pending != null && activity != null) {
            bind();
        } else {
            pending = null;
            if (activity != null) Toast.makeText(activity, "Permissão do Shizuku negada.", Toast.LENGTH_SHORT).show();
        }
    };

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = IFileService.Stub.asInterface(binder);
            Consumer<IFileService> cb = pending;
            pending = null;
            if (cb != null) cb.accept(service);
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            service = null;
        }
    };

    public void attach(Activity activity) {
        this.activity = activity;
        Shizuku.addRequestPermissionResultListener(permissionListener);
    }

    public void release() {
        try {
            Shizuku.removeRequestPermissionResultListener(permissionListener);
            if (args != null) Shizuku.unbindUserService(args, connection, true);
        } catch (Throwable ignored) {
            // O Shizuku pode já ter sido encerrado.
        }
        service = null;
        pending = null;
        activity = null;
    }

    public State state() {
        if (activity == null) return State.NOT_INSTALLED;
        try {
            activity.getPackageManager().getPackageInfo(SHIZUKU_PACKAGE, 0);
        } catch (PackageManager.NameNotFoundException e) {
            return State.NOT_INSTALLED;
        }
        try {
            if (!Shizuku.pingBinder()) return State.NOT_RUNNING;
            if (Shizuku.isPreV11() || Shizuku.getVersion() < 11) return State.OUTDATED;
            return Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                    ? State.READY : State.NEEDS_PERMISSION;
        } catch (Throwable t) {
            return State.NOT_RUNNING;
        }
    }

    /** Garante o Shizuku pronto (explicando o que falta, se for o caso) e entrega o serviço na thread principal. */
    public void ensureReady(Consumer<IFileService> onReady) {
        if (activity == null) return;
        if (service != null && service.asBinder().pingBinder()) {
            onReady.accept(service);
            return;
        }
        switch (state()) {
            case NOT_INSTALLED:
                new MaterialAlertDialogBuilder(activity)
                        .setTitle("Shizuku não encontrado")
                        .setMessage("O modo avançado usa o app Shizuku para ler as pastas de dados de outros apps. "
                                + "Instale o Shizuku, inicie o serviço por depuração sem fio e volte aqui. "
                                + "Os demais recursos do Zelo funcionam sem ele.")
                        .setNegativeButton("Agora não", null)
                        .setPositiveButton("Abrir página do Shizuku", (d, w) -> openUrl("https://shizuku.rikka.app/"))
                        .show();
                break;
            case NOT_RUNNING:
                new MaterialAlertDialogBuilder(activity)
                        .setTitle("Shizuku não está em execução")
                        .setMessage("Abra o Shizuku e inicie o serviço (por depuração sem fio, ou root se o aparelho tiver). "
                                + "Depois volte ao Zelo e tente de novo.")
                        .setNegativeButton("Agora não", null)
                        .setPositiveButton("Abrir Shizuku", (d, w) -> openShizuku())
                        .show();
                break;
            case OUTDATED:
                new MaterialAlertDialogBuilder(activity)
                        .setTitle("Shizuku desatualizado")
                        .setMessage("Atualize o Shizuku para uma versão recente e tente de novo.")
                        .setPositiveButton("OK", null).show();
                break;
            case NEEDS_PERMISSION:
                pending = onReady;
                Shizuku.requestPermission(REQUEST_CODE);
                break;
            case READY:
            default:
                pending = onReady;
                bind();
                break;
        }
    }

    private void bind() {
        if (activity == null) return;
        args = new Shizuku.UserServiceArgs(new ComponentName(activity.getPackageName(), FileService.class.getName()))
                .daemon(false)
                .processNameSuffix("zelo_files")
                .debuggable(false)
                .version(1);
        try {
            Shizuku.bindUserService(args, connection);
        } catch (Throwable t) {
            pending = null;
            Toast.makeText(activity, "Não foi possível conectar ao Shizuku.", Toast.LENGTH_LONG).show();
        }
    }

    private void openShizuku() {
        Intent launch = activity.getPackageManager().getLaunchIntentForPackage(SHIZUKU_PACKAGE);
        if (launch != null) activity.startActivity(launch);
    }

    private void openUrl(String url) {
        try {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(activity, "Não foi possível abrir o navegador.", Toast.LENGTH_SHORT).show();
        }
    }
}
