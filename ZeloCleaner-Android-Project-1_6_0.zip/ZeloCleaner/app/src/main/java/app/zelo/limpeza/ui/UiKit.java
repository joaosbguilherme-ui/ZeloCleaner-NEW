package app.zelo.limpeza.ui;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import app.zelo.limpeza.R;
import app.zelo.limpeza.model.FileCategory;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.color.MaterialColors;
import com.google.android.material.shape.MaterialShapeDrawable;
import com.google.android.material.shape.ShapeAppearanceModel;

/** Design system do Zelo, baseado em Material 3 para Views. */
public final class UiKit {
    // Paleta lida do tema ativo. Isso permite Material You e temas claro/escuro reais.
    public static int BG = 0xFF101511;
    public static int SURFACE = 0xFF171E19;
    public static int CARD = 0xFF1D2620;
    public static int CARD_ALT = 0xFF29362E;
    public static int ACCENT = 0xFFA8DCC1;
    public static int ACCENT_CONTAINER = 0xFF28533E;
    public static int ON_ACCENT_CONTAINER = 0xFFC5F2D8;
    public static int TEXT = 0xFFE2E9E2;
    public static int MUTED = 0xFFB9C8BC;
    public static int OUTLINE = 0xFF829388;
    public static int OUTLINE_VARIANT = 0xFF3C4A40;
    public static int SECONDARY = 0xFFB9D0C1;
    public static int TERTIARY = 0xFFD7C8A6;
    public static int SECONDARY_CONTAINER = 0xFF354B3C;
    public static int ON_SECONDARY_CONTAINER = 0xFFD5EBDD;
    public static int WARNING = 0xFFE8C98D;
    public static int WARNING_CONTAINER = 0xFF554A2F;
    public static int ON_WARNING_CONTAINER = 0xFFF4E4BF;
    public static int DANGER = 0xFFFFB4AB;
    public static int DANGER_CONTAINER = 0xFF93000A;
    public static int ON_DANGER_CONTAINER = 0xFFFFDAD6;

    /** Atualiza a paleta depois de aplicar o tema e, quando disponível, as cores dinâmicas. */
    public static void applyTheme(Context context) {
        BG = MaterialColors.getColor(context, com.google.android.material.R.attr.colorSurface, BG);
        SURFACE = MaterialColors.getColor(context, com.google.android.material.R.attr.colorSurfaceContainerLow, SURFACE);
        CARD = MaterialColors.getColor(context, com.google.android.material.R.attr.colorSurfaceContainer, CARD);
        CARD_ALT = MaterialColors.getColor(context, com.google.android.material.R.attr.colorSurfaceContainerHigh, CARD_ALT);
        ACCENT = MaterialColors.getColor(context, com.google.android.material.R.attr.colorPrimary, ACCENT);
        ACCENT_CONTAINER = MaterialColors.getColor(context, com.google.android.material.R.attr.colorPrimaryContainer, ACCENT_CONTAINER);
        ON_ACCENT_CONTAINER = MaterialColors.getColor(context, com.google.android.material.R.attr.colorOnPrimaryContainer, ON_ACCENT_CONTAINER);
        TEXT = MaterialColors.getColor(context, com.google.android.material.R.attr.colorOnSurface, TEXT);
        MUTED = MaterialColors.getColor(context, com.google.android.material.R.attr.colorOnSurfaceVariant, MUTED);
        OUTLINE = MaterialColors.getColor(context, com.google.android.material.R.attr.colorOutline, OUTLINE);
        OUTLINE_VARIANT = MaterialColors.getColor(context, com.google.android.material.R.attr.colorOutlineVariant, OUTLINE_VARIANT);
        SECONDARY = MaterialColors.getColor(context, com.google.android.material.R.attr.colorSecondary, SECONDARY);
        SECONDARY_CONTAINER = MaterialColors.getColor(context, com.google.android.material.R.attr.colorSecondaryContainer, SECONDARY_CONTAINER);
        ON_SECONDARY_CONTAINER = MaterialColors.getColor(context, com.google.android.material.R.attr.colorOnSecondaryContainer, ON_SECONDARY_CONTAINER);
        TERTIARY = MaterialColors.getColor(context, com.google.android.material.R.attr.colorTertiary, TERTIARY);
        WARNING = TERTIARY;
        WARNING_CONTAINER = MaterialColors.getColor(context, com.google.android.material.R.attr.colorTertiaryContainer, WARNING_CONTAINER);
        ON_WARNING_CONTAINER = MaterialColors.getColor(context, com.google.android.material.R.attr.colorOnTertiaryContainer, ON_WARNING_CONTAINER);
        DANGER = MaterialColors.getColor(context, com.google.android.material.R.attr.colorError, DANGER);
        DANGER_CONTAINER = MaterialColors.getColor(context, com.google.android.material.R.attr.colorErrorContainer, DANGER_CONTAINER);
        ON_DANGER_CONTAINER = MaterialColors.getColor(context, com.google.android.material.R.attr.colorOnErrorContainer, ON_DANGER_CONTAINER);
    }

    private final Context context;

    public UiKit(Context context) {
        this.context = context;
    }

    public int dp(float value) {
        return (int) (value * context.getResources().getDisplayMetrics().density + 0.5f);
    }

    public TextView text(String value, int sizeSp, int color, boolean bold) {
        TextView t = new TextView(context);
        t.setText(value);
        t.setTextSize(sizeSp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setIncludeFontPadding(true);
        t.setLineSpacing(dp(1), 1.0f);
        return t;
    }

    /** Botão Material 3 com superfície/tom recebidos pelo chamador. */
    public MaterialButton button(String label, int background, int foreground) {
        MaterialButton b = new MaterialButton(context, null, com.google.android.material.R.attr.materialButtonStyle);
        b.setText(label);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setTextColor(foreground);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setBackgroundTintList(ColorStateList.valueOf(background));
        b.setCornerRadius(dp(16));
        b.setInsetTop(0);
        b.setInsetBottom(0);
        b.setInsetLeft(0);
        b.setInsetRight(0);
        b.setMinHeight(dp(48));
        b.setMinimumHeight(dp(48));
        b.setMinimumWidth(0);
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setRippleColor(ColorStateList.valueOf(withAlpha(ACCENT, 0x24)));
        b.setElevation(0f);
        return b;
    }

    public GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    /** Fundo com cantos e contorno tonal, conforme a linguagem de superfícies do M3. */
    public MaterialShapeDrawable surfaceDrawable(int color, int radiusDp) {
        ShapeAppearanceModel shape = ShapeAppearanceModel.builder()
                .setAllCornerSizes(dp(radiusDp))
                .build();
        MaterialShapeDrawable drawable = new MaterialShapeDrawable(shape);
        drawable.setFillColor(ColorStateList.valueOf(color));
        drawable.setStroke(dp(1), ColorStateList.valueOf(OUTLINE_VARIANT));
        return drawable;
    }

    private static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }

    public Drawable rippleSurface(int color, int radiusDp) {
        return new RippleDrawable(
                ColorStateList.valueOf(withAlpha(ACCENT, 0x24)),
                surfaceDrawable(color, radiusDp),
                null
        );
    }

    public LinearLayout card() {
        LinearLayout c = new LinearLayout(context);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(18), dp(18), dp(18));
        c.setBackground(surfaceDrawable(CARD, 24));
        return c;
    }

    // ---------- cores e ícones por categoria ----------

    private static final int[] CATEGORY_COLORS = {
            0xFF3FA796, // imagens
            0xFF7E6BD6, // vídeos
            0xFFE0A030, // áudio
            0xFF4A90D9, // documentos
            0xFFD9774A, // compactados
            0xFF6BAF4B, // instaladores
            0xFF8A948C  // outros
    };

    public static int categoryColor(FileCategory c) {
        return CATEGORY_COLORS[c.ordinal() % CATEGORY_COLORS.length];
    }

    public static int categoryIcon(FileCategory c) {
        switch (c) {
            case IMAGES: return R.drawable.ic_image;
            case VIDEOS: return R.drawable.ic_video;
            case AUDIO: return R.drawable.ic_audio;
            case DOCUMENTS: return R.drawable.ic_doc;
            case ARCHIVES: return R.drawable.ic_archive;
            case APPS: return R.drawable.ic_apps;
            default: return R.drawable.ic_file;
        }
    }

    public static int withAlphaColor(int color, int alpha) {
        return withAlpha(color, alpha);
    }

    // ---------- ícones e componentes ----------

    /** Ícone vetorial tingido; o tamanho é definido pelo chamador nos LayoutParams. */
    public ImageView icon(int resId, int tint) {
        ImageView v = new ImageView(context);
        v.setImageResource(resId);
        v.setImageTintList(ColorStateList.valueOf(tint));
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        v.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        return v;
    }

    /** Quadro arredondado com um ícone centralizado. O tamanho do quadro vem dos LayoutParams do chamador. */
    public FrameLayout badge(int resId, int tint, int background, int iconDp, int radiusDp) {
        FrameLayout box = new FrameLayout(context);
        box.setBackground(rounded(background, radiusDp));
        box.addView(icon(resId, tint), new FrameLayout.LayoutParams(dp(iconDp), dp(iconDp), Gravity.CENTER));
        return box;
    }

    /** Botão circular de ícone (48 dp) com ondulação. */
    public FrameLayout iconButton(int resId, String description, Runnable action) {
        FrameLayout box = badge(resId, TEXT, CARD_ALT, 24, 24);
        box.setBackground(new RippleDrawable(ColorStateList.valueOf(withAlpha(ACCENT, 0x30)), rounded(CARD_ALT, 24), null));
        box.setContentDescription(description);
        box.setClickable(true);
        box.setFocusable(true);
        box.setOnClickListener(v -> action.run());
        return box;
    }

    /** Barra superior: botão de voltar e título. */
    public LinearLayout topBar(String title, Runnable onBack) {
        LinearLayout bar = new LinearLayout(context);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(iconButton(R.drawable.ic_arrow_back, "Voltar", onBack), new LinearLayout.LayoutParams(dp(48), dp(48)));
        TextView t = text(title, 18, TEXT, true);
        t.setMaxLines(1);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.leftMargin = dp(12);
        bar.addView(t, lp);
        return bar;
    }

    /** Selo pequeno (pílula) com texto. */
    public TextView chip(String value, int background, int foreground) {
        TextView t = text(value, 11, foreground, true);
        t.setPadding(dp(10), dp(3), dp(10), dp(3));
        t.setBackground(rounded(background, 10));
        return t;
    }

    /** Botão com ícone opcional (resId != 0), no início ou no fim do texto. */
    public MaterialButton button(String label, int background, int foreground, int iconRes, boolean iconAtEnd) {
        MaterialButton b = button(label, background, foreground);
        if (iconRes != 0) {
            b.setIconResource(iconRes);
            b.setIconTint(ColorStateList.valueOf(foreground));
            b.setIconSize(dp(20));
            b.setIconPadding(dp(8));
            b.setIconGravity(iconAtEnd ? MaterialButton.ICON_GRAVITY_TEXT_END : MaterialButton.ICON_GRAVITY_TEXT_START);
        }
        return b;
    }

    /** Fundo com cantos superiores arredondados (barras inferiores). */
    public MaterialShapeDrawable topSheetDrawable(int color, int radiusDp) {
        ShapeAppearanceModel shape = ShapeAppearanceModel.builder()
                .setTopLeftCornerSize(dp(radiusDp))
                .setTopRightCornerSize(dp(radiusDp))
                .setBottomLeftCornerSize(0f)
                .setBottomRightCornerSize(0f)
                .build();
        MaterialShapeDrawable drawable = new MaterialShapeDrawable(shape);
        drawable.setFillColor(ColorStateList.valueOf(color));
        drawable.setStroke(dp(1), ColorStateList.valueOf(OUTLINE_VARIANT));
        return drawable;
    }

    /** Entrada suave (fade + deslize); o atraso cresce com o índice para um efeito escalonado. */
    public void reveal(View v, int index) {
        v.setAlpha(0f);
        v.setTranslationY(dp(14));
        v.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(Math.min(index, 8) * 35L)
                .setDuration(260L)
                .setInterpolator(new DecelerateInterpolator())
                .start();
    }

    /** Aplica {@link #reveal} a todos os filhos diretos do contêiner. */
    public void revealChildren(LinearLayout container) {
        for (int i = 0; i < container.getChildCount(); i++) reveal(container.getChildAt(i), i);
    }
}
