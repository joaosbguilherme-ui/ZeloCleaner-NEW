package app.zelo.limpeza.scan;

import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.model.ScanMode;
import app.zelo.limpeza.util.Formatters;

import java.util.List;
import java.util.Locale;

/** Monta o texto do relatório compartilhado. */
public final class ReportBuilder {
    public static final int MAX_ITEMS = 500;

    private ReportBuilder() { }

    public static String build(ScanMode mode, String folderName, String dateText, int scanned,
                               List<ScanFile> found, Locale locale) {
        long total = 0;
        for (ScanFile f : found) total += f.size;
        StringBuilder sb = new StringBuilder();
        sb.append("Zelo — ").append(mode.title).append('\n');
        sb.append("Pasta: ").append(folderName).append('\n');
        sb.append("Data: ").append(dateText).append('\n');
        sb.append("Arquivos examinados: ").append(scanned).append('\n');
        sb.append("Itens encontrados: ").append(found.size()).append(" (")
                .append(Formatters.formatBytes(total, locale)).append(")\n\n");
        int limit = Math.min(found.size(), MAX_ITEMS);
        for (int i = 0; i < limit; i++) {
            ScanFile f = found.get(i);
            sb.append(Formatters.formatBytes(f.size, locale)).append("  ").append(f.relativePath)
                    .append("  [").append(f.reason).append("]\n");
        }
        if (found.size() > limit) sb.append("\n… e mais ").append(found.size() - limit).append(" item(ns) não listados.\n");
        return sb.toString();
    }
}
