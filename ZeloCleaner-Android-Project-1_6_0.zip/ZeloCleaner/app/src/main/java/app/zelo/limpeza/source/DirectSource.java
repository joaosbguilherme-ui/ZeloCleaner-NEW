package app.zelo.limpeza.source;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.provider.MediaStore;

import androidx.core.content.FileProvider;

import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.scan.LocalLister;
import app.zelo.limpeza.scan.PathGuard;
import app.zelo.limpeza.scan.TreeWalker;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Armazenamento interno completo, lido com java.io.File. Exige "Acesso a todos os arquivos". */
public final class DirectSource implements FileSource {
    private final Context context;
    private final File root;

    public DirectSource(Context context, File root) {
        this.context = context.getApplicationContext();
        this.root = root;
    }

    @Override public String label() { return "Armazenamento interno"; }

    @Override
    public TreeWalker.Summary scan(BooleanSupplier cancelled, Consumer<ScanFile> onFile) {
        return TreeWalker.walk(new LocalLister(), root.getAbsolutePath(), cancelled, onFile);
    }

    @Override
    public InputStream open(ScanFile file) throws IOException {
        return new FileInputStream(file.documentId);
    }

    @Override
    public boolean delete(ScanFile file) {
        File f = new File(file.documentId);
        // Só exclui arquivos comuns dentro da raiz analisada.
        if (!PathGuard.isStrictlyInside(root.getPath(), f.getPath()) || !f.isFile()) return false;
        return f.delete();
    }

    @Override
    public Uri viewUri(ScanFile file) {
        File f = new File(file.documentId);
        if (!PathGuard.isStrictlyInside(root.getPath(), f.getPath())) return null;
        try {
            return FileProvider.getUriForFile(context, context.getPackageName() + ".files", f);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public Bitmap thumbnail(ScanFile file, int sizePx) {
        try {
            if (file.mimeType.startsWith("image/")) {
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                BitmapFactory.decodeFile(file.documentId, bounds);
                int sample = 1;
                while (bounds.outWidth / (sample * 2) >= sizePx && bounds.outHeight / (sample * 2) >= sizePx) sample *= 2;
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = sample;
                return BitmapFactory.decodeFile(file.documentId, opts);
            }
            if (file.mimeType.startsWith("video/")) {
                return ThumbnailUtils.createVideoThumbnail(file.documentId, MediaStore.Images.Thumbnails.MINI_KIND);
            }
        } catch (Exception | OutOfMemoryError e) {
            return null;
        }
        return null;
    }
}
