package app.zelo.limpeza.scan;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

/** Lista pastas com java.io.File. Não segue links simbólicos, para evitar ciclos e sair da pasta raiz. */
public final class LocalLister implements TreeWalker.Lister {
    @Override
    public List<TreeWalker.Entry> list(String dirId) {
        List<TreeWalker.Entry> out = new ArrayList<>();
        File[] kids = new File(dirId).listFiles();
        if (kids == null) return out;
        for (File k : kids) {
            try {
                if (Files.isSymbolicLink(k.toPath())) continue;
            } catch (RuntimeException e) {
                continue;
            }
            boolean dir = k.isDirectory();
            out.add(new TreeWalker.Entry(k.getAbsolutePath(), k.getName(), dir, dir ? 0L : k.length(), k.lastModified(), null));
        }
        return out;
    }
}
