package app.zelo.limpeza.scan;

import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.model.ScanMode;

import java.util.Locale;

/** Regras (heurísticas) de classificação. Sem dependência do Android, para poder ser testada. */
public final class FileClassifier {
    public static final long LARGE_FILE_BYTES = 100L * 1024L * 1024L;
    public static final long OLD_FILE_AGE_MS = 180L * 24L * 60L * 60L * 1000L;

    private FileClassifier() { }

    /** Retorna o motivo pelo qual o arquivo entra no modo, ou null se não entra. Não vale para DUPLICATES. */
    public static String reasonFor(ScanMode mode, ScanFile f, long nowMs) {
        switch (mode) {
            case LARGE:
                return f.size >= LARGE_FILE_BYTES ? "Pelo menos 100 MB" : null;
            case OLD:
                return f.modified > 0 && f.modified < nowMs - OLD_FILE_AGE_MS ? "Sem alteração há 180 dias ou mais" : null;
            case JUNK:
                return looksLikeJunk(f.name, f.relativePath) ? "Nome ou pasta sugere arquivo temporário" : null;
            default:
                return null;
        }
    }

    public static boolean looksLikeJunk(String fileName, String relativePath) {
        String name = fileName.toLowerCase(Locale.ROOT);
        String path = relativePath.toLowerCase(Locale.ROOT).replace('\\', '/');
        return name.endsWith(".tmp") || name.endsWith(".temp") || name.endsWith(".bak")
                || name.endsWith(".old") || name.endsWith(".log") || name.equals("thumbs.db")
                || name.equals(".ds_store") || name.startsWith(".trashed")
                || path.startsWith("temp/") || path.startsWith("tmp/") || path.startsWith("cache/")
                || path.contains("/temp/") || path.contains("/tmp/") || path.contains("/cache/");
    }
}
