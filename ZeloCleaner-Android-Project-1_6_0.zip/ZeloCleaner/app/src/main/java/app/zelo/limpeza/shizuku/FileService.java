package app.zelo.limpeza.shizuku;

import android.os.ParcelFileDescriptor;

import app.zelo.limpeza.scan.EntryCodec;
import app.zelo.limpeza.scan.PathGuard;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Roda no processo de shell do Shizuku. Por segurança, só aceita caminhos dentro de Android/ e só
 * exclui arquivos comuns dentro de Android/data e Android/obb. Nunca executa comandos arbitrários.
 */
public class FileService extends IFileService.Stub {
    public static final String ANDROID_ROOT = "/storage/emulated/0/Android";
    private static final String DATA = ANDROID_ROOT + "/data";
    private static final String OBB = ANDROID_ROOT + "/obb";

    public FileService() { }

    @Override
    public void destroy() {
        System.exit(0);
    }

    private static boolean listable(String path) {
        return path.equals(ANDROID_ROOT) || path.equals(DATA) || path.equals(OBB)
                || PathGuard.isStrictlyInsideAny(path, DATA, OBB);
    }

    @Override
    public String[] listDir(String path, int offset, int max) {
        if (path == null || !listable(path) || offset < 0 || max <= 0) return null;
        File[] kids = new File(path).listFiles();
        if (kids == null) return new String[0];
        Arrays.sort(kids);
        List<String> lines = new ArrayList<>();
        for (int i = offset; i < kids.length && lines.size() < max; i++) {
            File k = kids[i];
            boolean dir = k.isDirectory();
            lines.add(EntryCodec.encode(k.getName(), dir, dir ? 0L : k.length(), k.lastModified()));
        }
        return lines.toArray(new String[0]);
    }

    @Override
    public ParcelFileDescriptor openRead(String path) {
        if (path == null || !PathGuard.isStrictlyInsideAny(path, DATA, OBB)) return null;
        File f = new File(path);
        if (!f.isFile()) return null;
        try {
            return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public boolean deleteFile(String path) {
        if (path == null || !PathGuard.isStrictlyInsideAny(path, DATA, OBB)) return false;
        File f = new File(path);
        return f.isFile() && f.delete();
    }

    @Override
    public String trimCaches(long bytes) {
        try {
            Process p = new ProcessBuilder("pm", "trim-caches", Long.toString(Math.max(1L, bytes)))
                    .redirectErrorStream(true).start();
            StringBuilder out = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null && out.length() < 2000) out.append(line).append('\n');
            }
            if (!p.waitFor(90, TimeUnit.SECONDS)) {
                p.destroy();
                return "tempo esgotado";
            }
            return "código " + p.exitValue() + (out.length() > 0 ? "\n" + out : "");
        } catch (Exception e) {
            return "erro: " + e.getMessage();
        }
    }
}
