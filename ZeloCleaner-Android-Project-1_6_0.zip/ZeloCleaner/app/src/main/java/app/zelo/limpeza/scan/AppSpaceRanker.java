package app.zelo.limpeza.scan;

import app.zelo.limpeza.model.SpaceSummary;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Agrupa pastas "data/<pacote>" e "obb/<pacote>" em um ranking de espaço por aplicativo. */
public final class AppSpaceRanker {
    public static final class AppSpace {
        public final String packageName;
        public long dataBytes;
        public long obbBytes;

        AppSpace(String packageName) {
            this.packageName = packageName;
        }

        public long total() {
            return dataBytes + obbBytes;
        }
    }

    private AppSpaceRanker() { }

    public static List<AppSpace> rank(List<SpaceSummary.FolderTotal> folders) {
        Map<String, AppSpace> byPackage = new HashMap<>();
        for (SpaceSummary.FolderTotal f : folders) {
            String[] parts = f.path.split("/");
            if (parts.length != 2 || parts[1].isEmpty()) continue;
            boolean data = parts[0].equals("data");
            boolean obb = parts[0].equals("obb");
            if (!data && !obb) continue;
            AppSpace app = byPackage.computeIfAbsent(parts[1], AppSpace::new);
            if (data) app.dataBytes += f.bytes;
            else app.obbBytes += f.bytes;
        }
        List<AppSpace> result = new ArrayList<>(byPackage.values());
        Collections.sort(result, (a, b) -> {
            int c = Long.compare(b.total(), a.total());
            return c != 0 ? c : a.packageName.compareTo(b.packageName);
        });
        return result;
    }
}
