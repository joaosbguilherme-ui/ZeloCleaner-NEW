package app.zelo.limpeza.model;

/** Um arquivo encontrado na pasta analisada. Não depende de classes do Android. */
public final class ScanFile {
    public final String documentId;
    public final String name;
    public final String relativePath;
    public final long size;
    public final long modified;
    public final String mimeType;
    public String reason = "";
    public boolean selected;

    public ScanFile(String documentId, String name, String relativePath, long size, long modified, String mimeType) {
        this.documentId = documentId;
        this.name = name;
        this.relativePath = relativePath;
        this.size = Math.max(0L, size);
        this.modified = modified;
        this.mimeType = mimeType == null ? "application/octet-stream" : mimeType;
    }

    public boolean isMedia() {
        return mimeType.startsWith("image/") || mimeType.startsWith("video/");
    }
}
