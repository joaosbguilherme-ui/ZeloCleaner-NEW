package app.zelo.limpeza.model;

/** Uma linha da lista de resultados: cabeçalho de grupo de duplicados ou arquivo. */
public final class ResultRow {
    public final DuplicateGroup group; // não nulo apenas em cabeçalhos
    public final ScanFile file;        // não nulo apenas em linhas de arquivo

    private ResultRow(DuplicateGroup group, ScanFile file) {
        this.group = group;
        this.file = file;
    }

    public static ResultRow header(DuplicateGroup group) {
        return new ResultRow(group, null);
    }

    public static ResultRow file(ScanFile file) {
        return new ResultRow(null, file);
    }

    public boolean isHeader() {
        return group != null;
    }
}
