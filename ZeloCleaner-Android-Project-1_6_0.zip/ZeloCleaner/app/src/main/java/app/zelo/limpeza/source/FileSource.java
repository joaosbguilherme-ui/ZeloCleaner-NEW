package app.zelo.limpeza.source;

import android.graphics.Bitmap;
import android.net.Uri;

import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.scan.DuplicateFinder;
import app.zelo.limpeza.scan.TreeWalker;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/**
 * De onde o Zelo lê e onde exclui: pasta escolhida (SAF), armazenamento completo ou Android/data via Shizuku.
 * Todos os métodos, exceto {@link #label()}, devem ser chamados fora da thread principal.
 */
public interface FileSource extends DuplicateFinder.ContentSource {
    /** Nome mostrado nas telas. */
    String label();

    TreeWalker.Summary scan(BooleanSupplier cancelled, Consumer<ScanFile> onFile);

    boolean delete(ScanFile file);

    /** Uri que outro app consegue abrir, ou null se esta fonte não permite. */
    Uri viewUri(ScanFile file);

    /** Miniatura ou null. */
    Bitmap thumbnail(ScanFile file, int sizePx);
}
