package app.zelo.limpeza.source;

import android.content.ContentResolver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;

import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.scan.TreeWalker;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Pasta escolhida pelo seletor oficial do Android (Storage Access Framework). */
public final class SafSource implements FileSource {
    private static final String[] COLUMNS = {
            Document.COLUMN_DOCUMENT_ID,
            Document.COLUMN_DISPLAY_NAME,
            Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE,
            Document.COLUMN_LAST_MODIFIED
    };

    private final ContentResolver resolver;
    private final Uri tree;
    private final String label;

    public SafSource(ContentResolver resolver, Uri tree, String label) {
        this.resolver = resolver;
        this.tree = tree;
        this.label = label;
    }

    @Override public String label() { return label; }

    private Uri documentUri(ScanFile f) {
        return DocumentsContract.buildDocumentUriUsingTree(tree, f.documentId);
    }

    /** Uma única consulta por pasta (bem mais rápido que DocumentFile.listFiles). */
    private List<TreeWalker.Entry> list(String dirId) throws IOException {
        List<TreeWalker.Entry> out = new ArrayList<>();
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, dirId);
        try (Cursor c = resolver.query(children, COLUMNS, null, null, null)) {
            if (c == null) return out;
            while (c.moveToNext()) {
                String mime = c.getString(2);
                boolean dir = Document.MIME_TYPE_DIR.equals(mime);
                out.add(new TreeWalker.Entry(c.getString(0), c.getString(1), dir,
                        c.isNull(3) ? 0L : c.getLong(3), c.isNull(4) ? 0L : c.getLong(4), dir ? null : mime));
            }
        } catch (RuntimeException e) {
            throw new IOException(e);
        }
        return out;
    }

    @Override
    public TreeWalker.Summary scan(BooleanSupplier cancelled, Consumer<ScanFile> onFile) {
        return TreeWalker.walk(this::list, DocumentsContract.getTreeDocumentId(tree), cancelled, onFile);
    }

    @Override
    public InputStream open(ScanFile file) throws IOException {
        InputStream in = resolver.openInputStream(documentUri(file));
        if (in == null) throw new IOException("sem conteúdo");
        return in;
    }

    @Override
    public boolean delete(ScanFile file) {
        try {
            return DocumentsContract.deleteDocument(resolver, documentUri(file));
        } catch (Exception e) {
            return false;
        }
    }

    @Override public Uri viewUri(ScanFile file) { return documentUri(file); }

    @Override
    public Bitmap thumbnail(ScanFile file, int sizePx) {
        try {
            return DocumentsContract.getDocumentThumbnail(resolver, documentUri(file), new Point(sizePx, sizePx), null);
        } catch (Exception e) {
            return null;
        }
    }
}
