package app.zelo.limpeza.util;

import android.os.Environment;
import android.os.StatFs;

import java.util.Locale;

/** Estatísticas reais da partição de dados do dispositivo. */
public final class StorageInfo {
    public final String usedText;
    public final String usedValueText;
    public final String freeValueText;
    public final String totalValueText;
    public final String subText;
    public final int percent;
    public final long totalBytes;
    public final long usedBytes;
    public final long freeBytes;

    private StorageInfo(String usedText, String usedValueText, String freeValueText,
                        String totalValueText, String subText, int percent,
                        long totalBytes, long usedBytes, long freeBytes) {
        this.usedText = usedText;
        this.usedValueText = usedValueText;
        this.freeValueText = freeValueText;
        this.totalValueText = totalValueText;
        this.subText = subText;
        this.percent = percent;
        this.totalBytes = totalBytes;
        this.usedBytes = usedBytes;
        this.freeBytes = freeBytes;
    }

    public static StorageInfo read() {
        Locale locale = Locale.getDefault();
        try {
            StatFs stats = new StatFs(Environment.getDataDirectory().getAbsolutePath());
            long total = Math.max(0L, stats.getTotalBytes());
            long free = Math.max(0L, stats.getAvailableBytes());
            long used = Math.max(0L, total - free);
            int percent = total > 0 ? (int) Math.min(100, Math.round(100.0 * used / total)) : 0;
            String usedValue = Formatters.formatBytes(used, locale);
            String freeValue = Formatters.formatBytes(free, locale);
            String totalValue = Formatters.formatBytes(total, locale);
            return new StorageInfo(usedValue + " usados", usedValue, freeValue, totalValue,
                    freeValue + " livres de " + totalValue, percent, total, used, free);
        } catch (Exception e) {
            return new StorageInfo("Indisponível", "—", "—", "—",
                    "Não foi possível ler as estatísticas deste dispositivo.", 0, 0, 0, 0);
        }
    }
}
