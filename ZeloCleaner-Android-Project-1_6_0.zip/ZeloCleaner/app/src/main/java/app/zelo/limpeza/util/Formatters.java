package app.zelo.limpeza.util;

import java.util.Locale;

public final class Formatters {
    private Formatters() { }

    public static String formatBytes(long bytes, Locale locale) {
        if (bytes < 1024) return bytes + " B";
        double value = bytes;
        String[] units = {"B", "KB", "MB", "GB", "TB"};
        int unit = 0;
        while (value >= 1024 && unit < units.length - 1) {
            value /= 1024;
            unit++;
        }
        return String.format(locale, "%.1f %s", value, units[unit]);
    }
}
