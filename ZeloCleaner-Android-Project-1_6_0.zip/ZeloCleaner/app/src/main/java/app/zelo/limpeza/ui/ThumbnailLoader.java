package app.zelo.limpeza.ui;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import app.zelo.limpeza.model.ScanFile;
import app.zelo.limpeza.source.FileSource;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Carrega miniaturas fora da thread principal, com cache em memória. */
final class ThumbnailLoader {
    private static final Bitmap MISSING = Bitmap.createBitmap(1, 1, Bitmap.Config.ALPHA_8);

    private final FileSource source;
    private final int sizePx;
    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(6 * 1024 * 1024) {
        @Override
        protected int sizeOf(String key, Bitmap value) {
            return value.getByteCount();
        }
    };

    ThumbnailLoader(FileSource source, int sizePx) {
        this.source = source;
        this.sizePx = sizePx;
    }

    /** Mostra a miniatura em {@code target} quando pronta; a tag evita aplicar em linhas já recicladas. */
    void load(ScanFile file, ImageView target) {
        final String key = file.documentId;
        target.setTag(key);
        target.setImageDrawable(null);
        Bitmap cached = cache.get(key);
        if (cached != null) {
            if (cached != MISSING) target.setImageBitmap(cached);
            return;
        }
        pool.execute(() -> {
            Bitmap bmp;
            try {
                bmp = source.thumbnail(file, sizePx);
            } catch (Exception e) {
                bmp = null;
            }
            final Bitmap result = bmp == null ? MISSING : bmp;
            cache.put(key, result);
            main.post(() -> {
                if (result != MISSING && key.equals(target.getTag())) target.setImageBitmap(result);
            });
        });
    }

    void shutdown() {
        pool.shutdownNow();
        main.removeCallbacksAndMessages(null);
        cache.evictAll();
    }
}
