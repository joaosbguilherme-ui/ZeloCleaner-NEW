# Zelo — manutenção do armazenamento Android

Projeto Android nativo em Java (versão 1.6.0), com interface própria, inspirado na categoria de ferramentas de manutenção e análise de arquivos. **Não é afiliado ao SD Maid/SD Maid SE e não reutiliza seu código ou identidade visual.**

## O que já funciona

**Análise (em qualquer fonte)**
- Painel inicial com medidor circular e métricas reais do armazenamento interno (espaço usado, livre, capacidade total e percentual).
- **Resumo do espaço:** barra e lista por categoria (imagens, vídeos, áudio, documentos, compactados, instaladores, outros) e as pastas que mais ocupam.
- Arquivos de 100 MB ou mais; arquivos sem alteração há 180 dias ou mais; possíveis temporários, logs e backups.
- Duplicados reais: agrupa por tamanho, filtra pelos primeiros 64 KB e confirma com SHA-256 completo. A cópia mais antiga é o original; as outras são sugeridas para revisão e aparecem agrupadas.
- Resultados em lotes enquanto a análise roda (dá para parar e manter o parcial), ordenáveis por tamanho, nome ou data, com miniaturas (quando a fonte oferece) e toque para abrir o arquivo antes de excluir.
- Seleção manual, confirmação antes de excluir, relatório de falhas e compartilhamento da lista como texto (até 500 itens).
- Botão/gesto voltar navega entre telas e cancela análises em andamento.
- Interface em português, tema escuro, sem anúncios e sem rede.

**Três fontes de análise** (tela inicial → *Fonte de análise* → *Alterar fonte*)

| Fonte | O que enxerga | O que exige |
|---|---|---|
| Pasta escolhida (padrão) | Só a pasta autorizada no seletor do Android | Nada além do seletor |
| Armazenamento completo | Todo o armazenamento interno, lido direto (mais rápido) | Android 11+ e a permissão "Acesso a todos os arquivos", concedida por você nas configurações |
| Android/data e obb (Shizuku) | Pastas de dados de outros apps | App Shizuku instalado, em execução e autorizado |

**Modo avançado (Shizuku, opcional)**
- *Apps por espaço:* quanto cada app guarda em `Android/data` e `Android/obb`.
- *Limpar caches dos apps:* pede ao sistema `pm trim-caches` e mostra quanto espaço livre foi ganho.
- Todas as ferramentas de análise e exclusão também funcionam sobre `Android/data` e `Android/obb` quando a fonte é o Shizuku.

## Como compilar

### Requisitos

- Android Studio recente com Android SDK Platform 36 instalado.
- JDK 17 ou superior compatível com o ambiente de compilação.
- Acesso à internet na primeira sincronização para baixar Gradle e dependências (inclui `androidx.core`, `documentfile`, Material Components para Android 1.14.0 e as bibliotecas `dev.rikka.shizuku:api` e `provider`, versão 13.1.5).

### Android Studio

1. Extraia o ZIP do projeto.
2. Abra a pasta `ZeloCleaner` no Android Studio.
3. Instale o Android SDK Platform 36, se solicitado.
4. Aguarde a sincronização do Gradle.
5. Use **Build > Build APK(s)**. O APK de debug costuma ficar em `app/build/outputs/apk/debug/`.

### Terminal

O projeto não inclui `gradle-wrapper.jar`; gere-o com `gradle wrapper` (Gradle instalado) ou use o Android Studio. Depois:

```sh
./gradlew assembleDebug
./gradlew testDebugUnitTest
```

## Como usar o Shizuku

1. Instale o Shizuku (https://shizuku.rikka.app/) e inicie o serviço (depuração sem fio, ou root se houver).
2. No Zelo, escolha *Alterar fonte → Android/data e obb (Shizuku)*, ou use *Apps por espaço* / *Limpar caches*.
3. Aceite o pedido de permissão do Shizuku.

Se o Shizuku não estiver disponível, o Zelo explica o que falta e o restante do app continua funcionando.

## Segurança e limites

- O modo padrão não pede permissões amplas. A permissão "Acesso a todos os arquivos" só é usada se você escolher a fonte *Armazenamento completo*; ela está declarada no manifesto, e a Google Play restringe esse tipo de permissão a certas categorias de app. Revise a política antes de publicar.
- O serviço do Shizuku **não executa comandos arbitrários**: ele só lista pastas dentro de `Android/`, abre para leitura e exclui **arquivos comuns** dentro de `Android/data` e `Android/obb` (caminhos conferidos contra `..` e links simbólicos), e roda `pm trim-caches`. Não apaga pastas inteiras, não desinstala apps e não limpa dados de apps (`pm clear`).
- Com a fonte *Armazenamento completo*, exclusões só atingem arquivos comuns dentro do armazenamento analisado.
- Mesmo com Shizuku, o Android pode bloquear partes do sistema; o shell não é root.
- Arquivos de `Android/data` não podem ser abertos por outros apps; nesse modo o toque no item informa isso.
- `pm trim-caches` depende da versão do Android e do fabricante; o Zelo mostra a resposta do sistema.
- Os nomes no ranking de apps só aparecem para apps visíveis ao Zelo (com ícone no launcher); os demais mostram o nome do pacote. O Zelo não afirma que uma pasta é "sobra" de app desinstalado, pois não consegue ter certeza.
- A detecção de "possível lixo" é heurística. Confira a lista antes de excluir.
- A exclusão pode ser permanente e não passa por uma lixeira do Zelo.
- A varredura tem teto de segurança de memória de 200.000 arquivos e 32 níveis; o resumo avisa quando é atingido.
- Miniaturas dependem da fonte (o Shizuku não as oferece).

## Estrutura

```text
app/src/main/
├── aidl/.../shizuku/IFileService.aidl     contrato do serviço que roda com permissão de shell
└── java/app/zelo/limpeza/
    ├── MainActivity.java                  navegação, estado e escolha de fonte
    ├── model/                             ScanFile, ScanMode, DuplicateGroup, SortOrder, FileCategory,
    │                                      SpaceSummary, ResultRow, RowBuilder (sem Android)
    ├── scan/                              TreeWalker, LocalLister, DuplicateFinder, FileClassifier,
    │                                      SpaceAnalyzer, AppSpaceRanker, PathGuard, EntryCodec, MimeTypes,
    │                                      ReportBuilder (sem Android) + ScanController (Android)
    ├── source/                            FileSource, SafSource, DirectSource, ShizukuSource, SourceType
    ├── shizuku/                           FileService (processo de shell), ShizukuHelper
    ├── ui/                                UiKit, ResultsScreen, SummaryViews, ThumbnailLoader, FileActions
    └── util/                              Formatters, StorageInfo
app/src/test/java/...                      testes unitários das classes sem Android
```

## Novidades da 1.6.0

- **Correção importante:** o app não derruba mais ao sair para segundo plano (`onStop` agora chama `super.onStop()`); abrir um arquivo da lista não marca mais a análise como parcial.
- Ícones vetoriais próprios no lugar de símbolos de texto; novo ícone adaptativo (com versão monocromática para ícones temáticos do Android 13+).
- Início redesenhado: marca no cabeçalho, cartão de armazenamento com anel animado e cor por nível (confortável / pouco espaço / quase cheio) e ferramentas em grade 2×2.
- Barra superior com botão de voltar circular em todas as telas; animação de entrada escalonada.
- Resultados: cartão de resumo com tamanho em destaque e barra de progresso, ícones coloridos por categoria, linhas selecionadas destacadas, etiqueta do motivo, estado vazio, pressionar e segurar para marcar, "Marcar cópias" por grupo de duplicados e barra de ações com contagem.
- Resumo do espaço: paleta de categorias distinta, barra empilhada com espaçamento e ícones; ranking de apps com o ícone real de cada app.
- Aparência: escolha de tema por cartões com ícones; a tela é restaurada após trocar o tema.
- Ícones e nome do app em recursos (`strings.xml`, `mipmap`).

## Novidades da 1.5.0

- Novo painel de armazenamento com indicador circular, porcentagem de uso e métricas de espaço usado, livre e capacidade total.
- Métricas do painel lidas diretamente de `StatFs` na partição de dados; não são confundidas com a soma dos arquivos da pasta selecionada.
- Tela de aparência com opções seguir sistema, claro e escuro.
- Material You: cores dinâmicas baseadas no papel de parede no Android 12+ (opcional), com fallback verde-mineral nos aparelhos anteriores ou quando desativadas.
- Paleta de interface centralizada e derivada dos atributos Material 3, incluindo cartões, indicadores, botões, relatórios e estados.
- Dependência `com.google.android.material:material:1.14.0`.

## Novidades da 1.3.0

- Interface `FileSource` com três fontes: pasta escolhida, armazenamento completo e Android/data via Shizuku.
- Resumo do espaço por categoria e por pasta.
- Modo avançado com Shizuku: apps por espaço e limpeza de caches.
- Varredura unificada em `TreeWalker`, testada com diretórios reais.
- 37 testes unitários.

## Histórico

- **1.4.0:** interface Material 3 inicial com superfícies tonais, botões e componentes redesenhados.
- **1.2.0:** resultados ordenáveis e agrupados, miniaturas, abrir arquivo, resultados em lotes, parar análise, código dividido em pacotes.
- **1.1.0:** voltar do sistema, cancelar análise, duplicados mais rápidos, relatório de falhas, compartilhar lista.

## Próximas melhorias sugeridas

- Lixeira do Zelo, filtros configuráveis e exclusões por pasta.
- Índice em SQLite para tirar o teto de arquivos e varredura incremental.
- Duplicados exibidos em fluxo, assim que cada grupo é confirmado.
- `RecyclerView`, ícone adaptativo, strings em `strings.xml` e onboarding.
- Testes instrumentados com provedores SAF diferentes e aparelhos reais para o `pm trim-caches`.

## Licença

Código inicial fornecido como projeto de demonstração. Revise e escolha uma licença antes de publicar ou redistribuir comercialmente.
